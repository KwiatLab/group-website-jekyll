function s = independent_set(measurements)
% Usage: s = independent_set(measurements)
%
% Produces a bitmap S denoting a linearly independent set of
% measurements.  This set of measurements can be exactly solved by
% linear tomography.

m = measurements(1,:)';
matrix = rho2stokes(m * m');
max_rank = length(matrix);

if(size(measurements,1) == max_rank)
  s = ones(size(measurements, 1), 1);
  return
end

s = zeros(size(measurements, 1), 1);
s(1) = 1;
cur_rank = 1;
for j=2:size(measurements,1)
    m = measurements(j,:)';
    sv = rho2stokes(m * m');
    if(rank([matrix,sv],.001) > cur_rank)
        matrix = [matrix,sv];
        cur_rank = cur_rank+1;
        s(j) = 1;
	if(cur_rank == max_rank)
		break
	end
    else
        s(j)=0;
    end
end

