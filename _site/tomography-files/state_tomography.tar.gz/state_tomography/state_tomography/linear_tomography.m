function [rho, intensity] = linear_tomography(data, measurements, m_set)
% Usage: [rho, intensity] = linear_tomography(data, M, m_set)
%
% A linear tomography is an exact solution to the equation
% data=trace(rho*M).  Rho is constrained to be hermetian, but not
% necessarily positive semi-definite.  The linear tomography is
% used to generate a starting point for the maximum likelihood
% search.
%
% If m_set is not specified, a complete (not over-complete) set of
% measurements are chosen to make the equation solvable.

if(nargin < 3)
  m_set = independent_set(measurements);
end

if(isscalar(m_set))
  n = length(data);
  linear_measurements = measurements;
  linear_data = data;
else
  n = sum(m_set);
  linear_measurements = measurements(find(m_set), :);
  linear_data = data(find(m_set));
end
linear_rho = zeros(size(measurements, 2));

B = B_matrix(linear_measurements);
B_inv = inv(B);

for j=1:n
  M(:,:,j) = M_matrix(j, linear_measurements, B, B_inv);
  linear_rho = linear_rho +  linear_data(j) * M(:,:,j);
end
intensity = trace(linear_rho);
rho = linear_rho / intensity;
