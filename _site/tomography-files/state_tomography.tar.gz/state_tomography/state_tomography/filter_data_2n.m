function [data, M1, M2, acc, conf] = filter_data_2n(raw_counts, intensities, conf)
% Usage: [data, M, acc, conf] = filter_data_2n(raw_counts, intensities, conf)
%
% Handles a wide variety of data correction and manipulation to
% convert the raw counts into a "normal form" for maximum
% liklihood.  The principle tasks are:
%
% Accidental correction
% Efficiency correction
% Crosstalk correction
% Intensity drift correction
% Error estimation
%
% Raw counts is of the form [time, s1, s2, s3, ..., c1, c2, c3, c4]
% where time  is the collection time for each measurement, s1..s4
% are the singles counts for each basis, then each part.  c1..cn
% are the coincidences for each basis pair.
%
% The following parameters are used from conf:
% 
% NQubits    integer           ->  Number of qubits
% Window     double array      ->  coincidence windows in ns
% Crosstalk  cell array of matricies ->  crosstalk matrix for each qudit
% Efficiency vector of doubles      ->  Efficiency for each
%                                       coincidence pair

% Setup:
if(~isscalar(intensities))
  conf.DoDriftCorrection='no';
end

nbits = getfield_default(conf, 'NQubits', 2);
do_drift_corr = getfield_default(conf, 'DoDriftCorrection', 'yes');
do_drift_corr = strcmpi(do_drift_corr, 'yes');

conf = setfield(conf, 'StateDimention', 2^nbits);

n_singles = 2*nbits;
n_coinc = 2^nbits;

t = raw_counts(:,1);
singles = raw_counts(:, 2:n_singles+1);
coinc = raw_counts(:, n_singles+2:n_singles+n_coinc+1);
settings = raw_counts(:,n_singles+n_coinc+2:end);

acc = zeros(size(coinc));
% Part 1: accedental correction
window = getfield_default(conf, 'Window', 0);
if(any(window > 0))
  for j=1:n_coinc
    idx=multiloop_index(j, 2*ones(1,nbits));
    idx = idx + (0:2:n_singles-2);
    acc(:,j) = prod(singles(:,idx), 2) .* (window(j)*1e-9./t).^(nbits - 1);
  end
end

% Part 2: Efficiency correction
eff = getfield_default(conf, 'Efficiency', 1);

% Part 3: Intensity map / drift correction

if(do_drift_corr)
  intensity_map = tensor_product(eye(size(raw_counts, 1)), ones(n_coinc, 1));
  z = zeros(prod(size(coinc)), 1);
  conf.IntensityMap = [z intensity_map];
end

% Part 4: Crosstalk  and Efficiency correction
ctalk = getfield_default(conf, 'Crosstalk', []);
for j =1:size(ctalk,3)
  crosstalk{j} = ctalk(:,:,j);
end

if(~isempty(crosstalk))
  big_crosstalk = tensor_product(crosstalk{:});
else
  big_crosstalk = eye(2^nbits);
end
big_crosstalk = big_crosstalk .* tensor_product(eff, ones(n_coinc, 1));
% Part 5: extract measurements

M = zeros(2^nbits, 2^nbits, prod(size(coinc)));
for j=1:size(coinc,1)
  M_twiddle = cell(1,2^nbits);
  U = 1;
  for k=1:nbits
    alpha = settings(j, 2*k-1);
    beta = settings(j, 2*k);
    psi_k = [alpha beta]';
    psip_k = [beta' -alpha']';
    U_k = [1;0] * psi_k' + [0;1] * psip_k';
    U = tensor_product(U, U_k);
  end
  for k=1:2^nbits
    M_twiddle{k} = U(:,k) * U(:,k)';
    M2((j-1)*n_coinc + k, :) = U(:,k)';
  end
  for k=1:2^nbits
    for l=1:2^nbits
      M(:,:,(j-1)*2^nbits+k) = ...
          M(:,:,(j-1)*2^nbits+k) + ...
          M_twiddle{l}*big_crosstalk(k,l);
    end
  end
end
M1 = M;

data = reshape(coinc.', prod(size(coinc)), 1);
acc = reshape(acc.', prod(size(acc)), 1);
