function [data,M1,M2,acc,conf]=filter_data_n(raw_counts, intensities, conf)
% Usage: [data,M,errors,conf]=filter_data_n(raw_counts, intensities, conf)
%
% Handles a wide variety of data correction and manipulation to
% convert the raw counts into a "normal form" for maximum
% liklihood.  The principle tasks are:
%
% Accidental correction
% Intensity drift correction
% Error estimation
%
% Raw counts is of the form [time, s1, s2, s3, ..., c]
% where time  is the collection time for each measurement, s1..s4
% are the singles counts for each arm, and c is the n-fold
% coincidences.
%
% The following parameters are used from conf:
% 
% Window             double            ->  coincidence window in ns
% QuditSizes         double array      ->  size of each qudit


qudit_sizes = getfield_default(conf, 'QuditSizes', [2 2]);
conf = setfield(conf, 'StateDimention', prod(qudit_sizes));
window = getfield_default(conf, 'Window', 0);
n_singles = length(qudit_sizes);
n_measurements = size(raw_counts, 1);

t = raw_counts(:,1);
singles = raw_counts(:, (1:n_singles)+1);
coinc = raw_counts(:, n_singles+2);
measurements = raw_counts(:, n_singles+3:end);

% Part 1: accidental corrections
acc = prod(singles, 2) .* (window * 1e-9./t).^(n_singles- 1);


% Part 2: Crosstalk  and Efficiency correction
%         Not used yet -- need to represent unitarys correctly
%         in 'settings', otherwise crosstalk is ambigious

ctalk = getfield_default(conf, 'Crosstalk', []);
for j =1:size(ctalk,3)
  crosstalk{j} = ctalk(:,:,j);
end

if(~isempty(crosstalk))
  big_crosstalk = tensor_product(crosstalk{:});
else
  big_crosstalk = [1, zeroes(1,2^nbits -1)];
end
%big_crosstalk = big_crosstalk .* tensor_product(eff, ones(n_coinc, 1));

% Part 3: extract measurements

M2 = zeros(n_measurements, prod(qudit_sizes));
M1 = zeros(prod(qudit_sizes), prod(qudit_sizes), n_measurements);
for j=1:n_measurements
  psi = 1;
  offset=0;
  for k=1:n_singles
    M_length = qudit_sizes(k);
    psi_k = measurements(j,offset+1:offset+M_length);
    psi = tensor_product(psi, psi_k);
    offset = offset + M_length;
  end
  M1(:,:,j) = psi'*psi;
  M2(j,:) = psi;
end
data = coinc;

