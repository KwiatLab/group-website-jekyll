function M=minimal_measurement_set(dim)
% Usage: M=minimal_measurement_set(dim)
%
% A minimal set of measurements to perform on a dim_1 X dim_2 X
% ... X dim_N Hilbert space.

N_measurements = prod(dim.^2);

M = zeros(N_measurements, sum(dim));

for j=1:N_measurements
  idx = multiloop_index(j, dim.^2);
  psi = [];
  for k=1:length(idx)
    n = fix((idx(k)-1)/dim(k))+1;
    m = mod(idx(k)-1, dim(k))+1;
    psi_k = zeros(1, dim(k));
    if(n<m)
      psi_k(n) = 1;
      psi_k(m) = 1;
      psi_k = psi_k/sqrt(2);
    elseif(n>m)
      psi_k(m) = 1;
      psi_k(n) = -i;
      psi_k = psi_k/sqrt(2);
    else % n==m
      psi_k(n) = 1;
    end
     psi = [psi psi_k];
  end
  M(j,:) = psi;
end
