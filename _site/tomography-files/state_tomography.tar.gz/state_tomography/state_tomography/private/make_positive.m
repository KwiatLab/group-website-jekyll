function rho=make_positive(rho_in)
% Usage: rho=make_positive(rho_in)
%
% Returns a positive semi-definate matrix that is similar to
% rho_in.  rho_in should be hermetian already.

[V,D] = eig(rho_in);
D = diag(D);

rho = 0 * rho_in;
for j=1:length(D)
    rho = rho + abs(D(j))*V(:,j)*V(:,j)';
end

rho = (rho + rho')/2;


