function val=getfield_default(s, name, default)
% Usage: val=getfield_default(s, name, default)
%
% If the field 'name' exists in s, return it.  Otherwise, return
% the default value.

if(isfield(s, name))
  val = s.(name);
else
  val = default;
end
