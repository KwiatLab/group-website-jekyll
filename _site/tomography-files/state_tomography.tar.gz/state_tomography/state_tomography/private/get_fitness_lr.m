function [L,R] = get_fitness_lr(tm, M);
% Usage: [L,R] = get_fitness_lr(tm, M);
%
% Precomputed two parameters used repeatedly by maxlike fitness.

num_M = size(M, 1);
size_M = size(M, 2);

L = cell(num_M, 1);
R = L;

for j=1:num_M
  tmp = M(j,:)*tm';
  L{j} = tmp;
  R{j} = tmp';
end
