function [val, jacob] = maxlike_fitness(t, data, accidentals, ...
                                            M, conf, A, B)
% Usage: [val, jacob] = maxlike_fitness(t, data, accidentals, M, conf,
% A, B)
%
% The fitness function to be optimized by the maximum liklihood
% search.  'data' is a column vector of the corrected coincidence
% counts, 'M' is a matrix of the measurements performed, one to a
% row, and 'conf' is a structure containing configuration
% information.  The fields of 'conf' are:
%
% UseDerivatives: 'yes' | 'no'  % return numerical derivatives
% AddOneCount:    'yes' | 'no'  % add +1 to all counts
% IntensityMap:   [array]       % Maps groups of counts sharing the
%                               % same intensity
% StateDimention:  numeric      % Dimention of Hilbert space
%

t = t(:);
addone = getfield_default(conf, 'AddOneCount', 1);
useder = getfield_default(conf, 'UseDerivatives', 1);
intmap = getfield_default(conf, 'IntensityMap', 1);
sz     = getfield_default(conf, 'StateDimention', 0);
n_data = size(data, 1);

if(ischar(addone))
  addone = strcmpi(addone, 'yes');
end
if(ischar(useder))
  useder = strcmpi(useder, 'yes');
end

n_int = size(intmap, 2)-1;
if(sz > 0)
  nt = sz^2;
else
  nt = length(t) - n_int;
  sz = sqrt(nt);
end

tm = t_matrix(t(1:nt));
rho = tm'*tm;

if(useder && nargout > 1)
  if(nargin < 7)
    [A, B] = initialize_fitness_globals(M);
    warning('A and B not set.  This will be slow');
  end
end

if(n_int > 0)
  rel_intensity =  (intmap * [1;t(nt+1: length(t))]);
else
  rel_intensity = ones(size(M, 3), 1);
end

prediction = zeros(size(M, 3), 1);
for j=1:length(prediction)
  prediction(j) = rel_intensity(j)*real(trace(M(:,:,j)*rho)) + accidentals(j);
end
prediction = max(prediction, .01);

val = (prediction - data) ./ sqrt(prediction);
if(nargout > 1 && useder)
  jacob1 = zeros(size(data,1), nt);
  for j=1:size(data,1)
    for k=1:nt
      tmp = A{j,k} * tm + tm' * B{j,k};
      jacob1(j,k) = rel_intensity(j)*trace(tmp) / sqrt(prediction(j));
      jacob1(j,k) = jacob1(j,k)*(1-.5+.5*data(j)/prediction(j));
    end
  end
  if(n_int > 0)
    tmp1 = (prediction-accidentals)./sqrt(prediction) .* ...
          (1 - .5 + .5* data./prediction);
    tmp2 = tensor_product(tmp1, 1./t(nt+1:end).');
    jacob2 = (intmap * [zeros(1,n_int);eye(n_int)]) .* tmp2;
    jacob = [jacob1, jacob2];
  else
    jacob = jacob1;
  end
end
%disp(sprintf('fval = %f', sum(val.^2)));
