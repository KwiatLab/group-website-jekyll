function tm=density2tm(rho)
%  Usage: tm=density2tm(rho)
%
% Performs a Cholesky factorization of rho (which must be positive
% semi-definite).  The result is a lower triangular matrix such
% that tm'*tm = rho.  If rho is positive definite, tm is unique, if
% this function chooses zero elements whenever possible.

% This is a recursive algorithm that finds the bottom row of the
% factorization, then recurses on the n-1 dimention matrix in the
% upper-left corner.  It could easily be made much more efficient
% by operating in place, rather than performing extra copies.
% We roughly follow an constructive proof of the Cholesky
% factorization as given in:
% http://www.netlib.org/utk/papers/factor/node9.html except that we
% define rho=tm'*tm  instead of rho=tm*tm', since that is the form
% described in "The Measurement of Qubits"
% http://prola.aps.org/abstract/PRA/v64/i5/e052312.

d = length(rho);
if(d==1)
  tm= real(sqrt(rho));
  return;
end
tm = zeros(size(rho));

last_element = rho(d,d);
tm(d,d) = real(sqrt(last_element));
if(last_element > 0)
  temp = rho(d, 1:d-1);
  tm(d,1:d-1) = temp / sqrt(last_element);
  recurse = rho(1:d-1,1:d-1) - temp' * temp / last_element;
else
  tm(d,1:d-1) = zeros(1,d-1);
  recurse = rho(1:d-1,1:d-1);
end

tm(1:d-1,1:d-1) = density2tm(recurse);
