function tm=t_matrix(t)
% Usage: tm = t_matrix(t)
%
% Converts a real vector 't' into a lower diagonal matrix for use
% in the maximum liklihood program.  tm'*tm is a hermetian matrix.

d = sqrt(length(t));

idx=1;
cur_length=d;
tm = zeros(d);

for j=1:d
  tm = tm + 1*diag(t(idx:idx+cur_length-1), 1-j);
  idx = idx + cur_length;
  
  if(j > 1)
    tm = tm + i*diag(t(idx:idx+cur_length-1), 1-j);
    idx = idx + cur_length;
  end
  cur_length = cur_length - 1;
end
