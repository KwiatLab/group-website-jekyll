function U = randcuefast(N)

% Creates random CUE (Haar-distributed unitary) matrix U by finding eigenvectors of a random 
% GUE (Hermitian) matrix H and constructing the matrix whose columns are its eigenvectors.

% n = log(N) is the number of qubits

% Generate diagonal elements of the Hermitian operator H
H = diag(randn(1,N));

% Perform the following test of the gaussian random numbers defining H:
% The independent matrix elements of H should all be gaussian distributed with mean zero, 
% with variance defined such that the average of the square modulus of the (complex) 
% off-diagonal elements is equal to the average square of the (real) diagonal elements.

% Generate off-diagonal elements for H with variance for real and imaginary components 
% a factor of two smaller than the diagonal components.
for j = 1:N
 for k = j+1:N;
H(j,k) = randn(1)/sqrt(2)+i*randn(1)/sqrt(2);
H(k,j) = conj(H(j,k));
 end
end

%Generate unitary
[U d] = eig(H);

for j = 1:N
    U(:,j) = U(:,j)*exp(-i*2*pi*rand(1));
end
