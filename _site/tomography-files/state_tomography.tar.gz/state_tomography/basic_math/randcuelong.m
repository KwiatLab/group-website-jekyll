function U = randcuelong(N)

% Creates random (Haar distributed) CUE unitary operator of dimension N

psi = 2*pi*rand(N-1,N-1);
chi = zeros(N-1);
chi(:,1) = 2*pi*rand(N-1,1);
xi = rand(N-1,N-1);
for x1 = 1:N-1
  for x2 = 1:N-1
    phi(x1,x2) = asin(xi(x1,x2)^(1/(2*x1)));
  end
end

E = cell(1,N-1);
for a = 1:N-1
 E{a} = eye(N);
 f = cell(1,a);
 for b = a:-1:1
  e = [exp(i*psi(b,a))*cos(phi(b,a))    exp(i*chi(b,a))*sin(phi(b,a)); 
      -exp(-i*chi(b,a))*sin(phi(b,a))   exp(-i*psi(b,a))*cos(phi(b,a))];
  f{b} = eye(N);
  f{b}(N-b:N-b+1,N-b:N-b+1) = e;
 end
 for v = 1:a
  E{a} = f{v}*E{a};
 end
end

U = eye(N);
for w = 1:N-1
 U = U*E{w};
end
