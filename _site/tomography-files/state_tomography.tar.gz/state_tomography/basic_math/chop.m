function val=chop(x)
% Usage: val=chop(x)
%
% Chops real and imaginary components less than 1E-10 in magnitude
% to zero.  Similar to the mathematica function of the same name,
% this is useful in eliminating small imaginary components of the
% eigenvalues of not-exactly hermetian matricies, without
% discarding imaginary off-diagonal elements or hiding errors due
% to "real" non-hermetian matricies.

  [r, c] = size(x);
  x = reshape(x, 1, r*c);
  ind1=find(abs(real(x)) < 1E-10);
  ind2=find(abs(imag(x)) < 1E-10);
  if(any(ind1))
    x(ind1) = imag(x(ind1)) * j;
  end
  if(any(ind2))
    x(ind2) = real(x(ind2));
  end
  val = reshape(x, r, c);
  
