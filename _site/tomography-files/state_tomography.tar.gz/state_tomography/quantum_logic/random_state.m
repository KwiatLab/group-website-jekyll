function psi=random_state(N)
% Usage: psi=random_state(N)
%
% Generates a random pure state psi of dimention N.  This is done
% by finding the first column of a random NxN unitary.

U = randcuefast(N);
psi = U(:,1);
