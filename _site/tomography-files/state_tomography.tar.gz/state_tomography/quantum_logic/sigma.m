function matrix=sigma(n)
% Usage val=sigma(i)
%
% Returns the i'th sigma matrix.  sigma(0) is the identity matrix,
% while sigma(1-3) are the Pauli matricies.  i can be a vector, in
% which case the return is the tensor product of each sigma
% matricies.

  matrix = 1;
  for k=1:length(n)
    switch n(k)
     case 0
      val=[1 0; 0 1];
     case 1
      val=[0 1; 1 0];
     case 2
      val=[0 -i; i 0];
     case 3
      val=[1 0; 0 -1];
     otherwise
      error('sigma:inval','Invalid sigma matrix');
    end
    matrix = tensor_product(matrix, val);
  end
  
