function val=WP(theta, phi)
% Usage: WP(theta, phi)
%
% Calculate the waveplate operator for a waveplate of retardance phi
% oriented with the optic axis at angle theta to horizontal.

tmp = [1, 0; 0, exp(i*phi)];
r=rotation_2d(theta);
val = r' * tmp * r;
