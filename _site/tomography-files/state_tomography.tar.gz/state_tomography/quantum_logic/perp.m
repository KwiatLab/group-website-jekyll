function rv = perp(psi);
% Usage: psip = perp(psi)
%
% Calculates the perpendicular state vector to the 1-qubit state
% psi.  perp(psi) is not unique for states larger than a single
% qubit, so perp returns a matrix of state vectors that span all
% orthogonal states.
%
% Usage: val = perp(rho)
%
% Calculates a generalized perpendicular, a set of state vectors
% orthogonal to the density matrix rho, ie, the set of eigenvectors
% with eigenvalue zero.
  
  if(size(psi,1) == 1)
    rv = null(psi)';
  elseif(size(psi,2) == 1)
    rv = null(psi');
  else
    [V,D] = eig(psi);
    idx = find(abs(diag(D)) < 1e-10)
    rv = V(:,idx);
  end
  if(prod(size(rv)) == 0)
    warning('perp: rho is full-rank -- the perpendicular space is {0}');
  end
  
