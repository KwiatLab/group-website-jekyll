function rho=random_density(N)
% Usage: rho=random_density(N)
%
% Generates a random NxN density matrix.

U = randcuefast(N);
rho = diag(rand(N, 1));
rho = rho/trace(rho);
rho = U*rho*U';
