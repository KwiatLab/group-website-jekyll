function rho = stokes2rho(S)
% Usage: rho = stokes2rho(S)
%
% The generalized stokes vector is defined as:
% rho = sum_{i=1}^{N} S(i) * \sigma_i
% where \sigma_i are the spinor matricies for rho.
%
% Currently, stokes2rho is limited to the case of N qubits,
% where the appropriate \sigma_i are simply tensor products of the
% Pauli matricies.

if(length(S) == 3)
  warning('3 element stokes vector depricated -- S(1) = 1');
  S = [1;reshape(S, 3, 1)];
end

N = length(S);
d = sqrt(N);
rho = 0;

for j=1:N
  rho = rho + S(j)*sigma_N(j, d);
end
rho = rho / d;
