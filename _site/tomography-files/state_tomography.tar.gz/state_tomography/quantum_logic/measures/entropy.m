function S = entropy(rho)
% Usage: S = entropy(rho)
%
% The Von Neumann entropy of a quantum state described by the
% density matrix rho.
  
  [ignore,D] = eig(rho);
  E = real(diag(D));
  S = 0;
  for a=1:length(E)
    if(E(a) > 0)
      S = S - E(a)*log2(E(a));
    end
  end
  
