function lin_e = linear_entropy(rho)
% Usage: lin_e = linear_entropy(rho)
%
% Calculates the linear entropy of a state rho.  This is given by
% the formula lin_e = 4/3 * (1- trace(rho^2));
%
  if(min(size(rho)) == 1)
    lin_e = 0;
  else
    d = length(rho);
    lin_e = d * real(1-trace(rho^2)) / (d-1);
  end
