function val=trace_dist(rho1, rho2)
% Usage: val=trace_dist(rho1, rho2)
%
% The trace distance between two states is the distance between
% their stokes vectors.
  
  s1 = rho2stokes(rho1);
  s2 = rho2stokes(rho2);
  s = s1 - s2;
  val=sqrt(s' * s)/2;
