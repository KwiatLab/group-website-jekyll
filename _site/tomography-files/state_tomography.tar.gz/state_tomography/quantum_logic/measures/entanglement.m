function E=entanglement(rho)
% Usage: E=entanglement(rho)
%
% Returns the entanglement of the two qubit state rho or a state
% vector.
  
  t = tangle(rho);
  x = (1 + sqrt(1-t))/2;
  if(x==0)
    E=0;
  elseif(x==1)
    E=1;
  else
    E = -x*log2(x) - (1-x)*log2(1-x);
  end
