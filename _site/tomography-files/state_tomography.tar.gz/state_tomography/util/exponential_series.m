function x=exponential_series(bound, density, decades)
% Usage: x=exponential_series(bound, density, decades)
%
% Generates an exponential series
% bound     Lower (or upper) bound
% density   number of points per decade
% decades   number of decades
%
% If density is negative, the first point (bound) will be of the
% largest abolute magnitude (an exponentially decreasing series).
% Otherwise, it will be the smallest in magnitude.

n = 0:1/density:sign(density)*decades;
x = bound * 10.^n;
