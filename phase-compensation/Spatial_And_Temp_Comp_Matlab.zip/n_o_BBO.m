function n_o = n_o_BBO(lambda)

%returns the ordinary index of refraction for BBO at the specific wavelength in microns

n_o = sqrt(2.7405 + 0.0184/(lambda^2 - 0.0179) - 0.0155*lambda^2);    %% BBO
