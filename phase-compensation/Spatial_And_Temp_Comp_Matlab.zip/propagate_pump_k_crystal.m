function [D_ext_after, S_int_fast, S_int_slow, delta_phi, D_int_slow, D_int_fast, flip_slow, flip_fast] = ...
    propagate_pump_k_crystal(D_ext_before, s_ext, lambda, crystal_param, D_int_slow_prev, D_int_fast_prev)

D_ext_before = normalize(D_ext_before);
phi_before = angle(D_ext_before);

s_int_slow = solve_refraction(s_ext, 1, 1, crystal_param, lambda, 1e-10, 100, 0, 1);
s_int_fast = solve_refraction(s_ext, 1, 2, crystal_param, lambda, 1e-10, 100, 0, 1);

[phi_slow, D_int_slow, S_int_slow] = phase(crystal_param, lambda, s_int_slow, 'slow');
[phi_fast, D_int_fast, S_int_fast] = phase(crystal_param, lambda, s_int_fast, 'fast');

flip_slow = 0;
flip_fast = 0;
% fix flipping error
if dot(D_int_slow, D_int_slow_prev) < 0
    D_int_slow = -D_int_slow;
    flip_slow = 1;
end

if dot(D_int_fast, D_int_fast_prev) < 0
    D_int_fast = -D_int_fast;
    flip_fast = 1;
end

% the following two vectors should form an orthonormal basis
D_slow_before = rotate_vector(D_int_slow, cross(s_int_slow, s_ext), acos(dot(s_int_slow, s_ext)));
D_fast_before = rotate_vector(D_int_fast, cross(s_int_fast, s_ext), acos(dot(s_int_fast, s_ext)));

D_ext_slow_component = abs(dot(D_ext_before, D_slow_before));
D_ext_fast_component = abs(dot(D_ext_before, D_fast_before));

D_ext_after = D_ext_fast_component*exp(i*phi_fast)*D_fast_before + D_ext_slow_component*exp(i*phi_slow)*D_slow_before;

D_ext_after = exp(i*phi_before).*D_ext_after;

% delta_phi=(phi_slow-phi_fast);
delta_phi=phi_fast-phi_slow;
% make the approximation that the input photon is mostly slow or fast in the crystal it is propagating through
% this approximation only affects the calculation of the external phase
% if abs(D_ext_slow_component) > abs(D_ext_fast_component)
%     S_int = S_int_slow;
%     phi = phi_slow;
% else
%     S_int = S_int_fast;
%     phi = phi_fast;
% end

end

