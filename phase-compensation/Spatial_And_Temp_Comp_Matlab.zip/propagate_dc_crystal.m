function [D_ext_after, S_int_slow, phi_slow, D_int_slow, flip_dc] = propagate_dc_crystal(s_ext, lambda, crystal_param, D_int_slow_prev)

% propagate polarization vector, D, through the crystal the photon was born in
% assume the photon was generated exactly in the center of the crystal
% will propagate photon through half the thickness of the crystal
% the generated photon will be the slow ray in the crystal it is born in (type-I down conversion)

crystal_param.crystal_thickness = crystal_param.crystal_thickness/2;

s_int_slow = solve_refraction(s_ext, 1, 1, crystal_param, lambda, 1e-10, 100, 0, 1);

% note that photon only propagating through 1/2 the thickness of the crystal
[phi_slow, D_int_slow, S_int_slow] = phase(crystal_param, lambda, s_int_slow, 'slow');

flip_dc = 0;
% fix flipping error
if dot(D_int_slow, D_int_slow_prev) < 0
    D_int_slow = -D_int_slow;
    flip_dc = 1;
end

% find the polarization vector after the crystal, before applying the phase aqcuired inside the crystal
D_ext_after = rotate_vector(D_int_slow, cross(s_int_slow, s_ext), acos(dot(s_int_slow, s_ext)));

% apply the phase acquired inside the crystal
D_ext_after = exp(i*phi_slow)*D_ext_after;

end
