function phase = phase_fast(lambda, d)

%returns the extraordinary index of refraction for quartz at the specific wavelength in microns

n_e = sqrt(2.6964507 + (-0.011596199)*lambda^2 + (-0.0001206215)*lambda^4 + 0.012383549/lambda^2 + (-0.31280678)*lambda^2*(lambda^2-0.019120036)/((lambda^2-0.019120036)^2 +0.015545792*lambda^2));  % Quartz
phase=2*pi*n_e*d/lambda