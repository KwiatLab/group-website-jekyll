function p = set_crystal_param(crystal_type, crystal_thickness, theta, phi, gamma)

p.crystal_type = crystal_type;
p.crystal_thickness = crystal_thickness;
p.theta = theta;
p.phi = phi;
p.gamma = gamma;
