function [d_comps,d_compi,maxT] = OptSpaComp_NonDegBiBO
filename_root='OptSpa Comp NonDeg BiBo'
dc_crystal = 'BiBO'; dc_crystal_thick = 0.6; %mm
dc_crystal_d = dc_crystal_thick*1000;
precomp_crystal = 'Quar'; precomp_crystal_thick =15.850; %mm 
pc_crystal_d = precomp_crystal_thick*1000;
pump_lambda = 405; %nm
lambda_p = pump_lambda/1000;
delta_lambda = 0.217; %nm
dlambda = delta_lambda/1000;
signal_lambda = 851.9; %nm
s_lambda = signal_lambda/1000;
idler_lambda = 772; %nm
i_lambda = idler_lambda/1000;
iris_diam_i=5; %mm
iris_diam_s=5; %mm
filter_pts=1;
iris_pts=5;
pump_w=950; %microns
iris_z=812; %mm

d_comps=245;
d_compi=245;


maxT=0;
    
pump = set_pump([cos(pi/4); sin(pi/4); 0], pump_w, 1e9, lambda_p, dlambda);
pre_comp = set_crystal_param(precomp_crystal(1,:), pc_crystal_d, pi/2, 0, pi/2);

 irises = set_irises([0;43.82;812], iris_diam_s/2, [0;-40.29;812], iris_diam_i/2, iris_pts, iris_pts,...
    iris_pts, iris_pts, pump_w);


filters = set_filters(s_lambda, 0.005, i_lambda, 0.005, filter_pts, filter_pts);

comp_on = 1;
custom_coeff = 0;




ccsgamma = [90, -90, 90, -90];
ccigamma = [-90, 90, 90, -90];
ccsgamma = ccsgamma*pi/180;
ccigamma = ccigamma*pi/180;
dc1theta = [151.7, 151.7, 151.7, 151.7];
dc2theta = [151.7, 151.7, 151.7, 151.7];
dc1theta = dc1theta*pi/180;
dc2theta = dc2theta*pi/180;
gamma1 = [0, 0, 0, 0];
gamma2 = [90, 90, 90, 90];
gamma1 = gamma1*pi/180;
gamma2 = gamma2*pi/180;
format compact



for jj = 1: 1: 1
    
for ii = 1: 1: 1
 for ds=270:10:290
  for di=200:10:220   
    comp_s = set_crystal_param('BBO1', ds, 33.9*pi/180, 0, ccsgamma(jj));
    comp_i = set_crystal_param('BBO1', di, 33.9*pi/180, 0, ccigamma(jj));

    dc_1 = set_crystal_param(dc_crystal(1,:), dc_crystal_d, dc1theta(1), pi/2, gamma1(1));
    dc_2 = set_crystal_param(dc_crystal(1,:), dc_crystal_d, dc2theta(1), pi/2, gamma2(1));
   % [rho, T, phases, irises, param, slow_flips, fast_flips, dc_flips] = ...
    %    phasemap_and_rho_v16d(irises, filters, pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff);
     [rho, T, phases, irises, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_v16dRia2(irises, filters,...
pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff);

    rho_T_array(jj,ii).s_comp = comp_s;
    rho_T_array(jj,ii).i_comp = comp_i;
    rho_T_array(jj,ii).dc1 = dc_1;
    rho_T_array(jj,ii).dc2 = dc_2;
    rho_T_array(jj,ii).Tangle = T;
    rho_T_array(jj,ii).Rho = rho;
%     rho_phase= atan2(imag(rho(1,4)),real(rho(1,4)));
%     disp([dc_flips(1), dc_flips(2), dc_flips(3), dc_flips(4), slow_flips(1), fast_flips(1),...
%         slow_flips(2), fast_flips(2), slow_flips(3), fast_flips(3), slow_flips(4), fast_flips(4), ...
%         slow_flips(5), fast_flips(5), slow_flips(6), fast_flips(6), slow_flips(7), fast_flips(7), ...
%         slow_flips(8), fast_flips(8), slow_flips(9), fast_flips(9), T])

    phase_total=phases.total_phase*180/pi;
     disp([ 'Signal Compensator Length= ' num2str(ds), 'Idler Compensator Length= ' num2str(di),' Tangle= ' num2str(T) ]);
    disp([num2str(param.iris_hits) ' photon pairs hit both irises out of ' num2str(param.max_hits) ' tries.']);
   % for kk=1:1:9
    %if slow_flips(kk)~=0
     %   disp(['slow_flips(' num2str(kk) ') = ' num2str(slow_flips(kk)) ', corrected'])
    %end
    %if fast_flips(kk)~=0
     %   disp(['fast_flips(' num2str(kk) ') = ' num2str(fast_flips(kk)) ', corrected'])
    %end
    %end
    if (maxT>T)
        maxT=T;
        d_comps=ds;
        d_compi=di;
        
  end
 end
end
end

c=fix(clock);
filename=[filename_root '-' num2str(c(1)) '-' num2str(c(2)) '-' num2str(c(3)) '-' num2str(c(4)) '-' num2str(c(5)) '-' num2str(c(6)) '.mat'];
save (filename)
end