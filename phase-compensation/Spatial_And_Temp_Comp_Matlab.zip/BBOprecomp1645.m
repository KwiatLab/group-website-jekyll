function [Tang]=BBOprecomp1645();

% compare 16 deg regular collection with migdall collection at 0.5mm iris



 % migdall collection precomp at 45
pump = set_pump([0; 1; 0], 1000, 1e9, 0.405, 0.004);
dc_1 = set_crystal_param('BBO1', 600, 40.72*pi/180, 0, 45*pi/180);
dc_2 = set_crystal_param('BBO1', 600, 40.72*pi/180, 0, 135*pi/180);
filters = set_filters(0.810, 0.01, 0.810, 0.01, 6, 6);
irises = set_irises([0;360;1200], 0.5, [0;-360;1200], 0.5, 6, 6, 6, 6,1000);
custom_coeff=0;
plot_map=0;
comp_on=0;
pre_comp = set_crystal_param('BBO1', 0, pi/2, 0, pi/2);
comp_s = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, -pi/2);
comp_i = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, pi/2);

for j =2000:100:6000
 
  pre_comp = set_crystal_param('BBO1', j, pi/2, 0,45*pi/180);

  [rho, T, phases, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_v16g(irises, filters,...
  pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff, plot_map)
  
  Tang(j/100-19)=T;

end
 
                
 % migdall collection precomp at 45





           