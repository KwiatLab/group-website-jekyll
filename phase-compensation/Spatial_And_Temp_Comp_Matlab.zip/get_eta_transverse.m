function t = get_eta_transverse(n_principal, crystal_to_s_coord_matrix);

% This is the dielectric tensor without epsilon_nought in front
dielectric_tensor = [(n_principal(1))^2 0 0; 0 (n_principal(2))^2 0; 0 0 (n_principal(3))^2];

% eta is the impermeability matrix
eta = inv(dielectric_tensor);

% eta_transformed is the impermeability matrix in the s coordinate system 
eta_transformed = crystal_to_s_coord_matrix*eta*inv(crystal_to_s_coord_matrix);

% Select the upper 2x2 section of eta_transformed, because the z components
% of D vectors must be zero (s and D are perpendicular, and s is in z direction)
% This truncated matrix is called eta_transverse (because it contains
% components transverse to s)
t = eta_transformed(1:2, 1:2);

end