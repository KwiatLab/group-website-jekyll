function pump = set_pump(D, w, R, lambda_center, lambda_width)

% D is the polarization vector of the pump
pump.D = normalize(D);

% w is the pump beam waist at the DC crystals, ans is 1/2 the diameter. 
pump.w = w;

% R is the radius of curvature of the wavefront of the pump at the crystal
% if a focusing lens is placed right before the crystal, the radius of curvature is approximately the focal length of the lens
pump.R = R;

% central wavelength of the pump beam, in microns
pump.lambda_center = lambda_center;
% full width at 1/e of the spectrum of the pump beam, in microns
pump.lambda_width = lambda_width;