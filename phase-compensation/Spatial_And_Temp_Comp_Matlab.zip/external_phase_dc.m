function phi_external_dc = external_phase_dc(dc_crystal_1, dc_crystal_2, lambda, S_1_in_1_slow, S_1_in_2_fast, S_2_in_2_slow, s_ext)

thickness_1 = dc_crystal_1.crystal_thickness;
thickness_2 = dc_crystal_2.crystal_thickness;

position_1 = [0;0;1/2*thickness_1] + thickness_1/2*S_1_in_1_slow/S_1_in_1_slow(3) + thickness_2*S_1_in_2_fast/S_1_in_2_fast(3);
position_2 = [0;0;thickness_1 + 1/2*thickness_2] + 1/2*thickness_2*S_2_in_2_slow/S_2_in_2_slow(3);

position_dist = norm(position_2 - position_1);
%position_2 - position_1;

phi_external_dc = 2*pi/lambda*position_dist*dot(normalize(position_2 - position_1), s_ext);
