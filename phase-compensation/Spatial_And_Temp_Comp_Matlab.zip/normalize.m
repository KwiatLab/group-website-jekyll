function x_out = normalize(x_in)

if norm(x_in) == 0
    x_out = 0;
else
    x_out = x_in/norm(x_in);
end