function [delta_t_precomp, delta_t_dc, delta_t_spatial_comp, delta_t_total] = temporal_delay_v2(spatial_comp, pre_comp, dc_1, dc_2, lambda_pump, lambda_dc, k_pump_ext, k_dc_ext);

% This function calculates the time delay between a down-converted wave packet born in the first crystal and the second crystal
% Calculation is done only for time delay for one side (either signal or idler depending on which k_dc_ext is supplied)
% k_pump_ext is the unit wave vector of the pump photon outside the crystals
% k_dc_ext is the unit wave vector of the down converted photon outside the crystals

% normalize just in case
k_pump_ext = normalize(k_pump_ext);
k_dc_ext = normalize(k_dc_ext);

% find the wave vectors of the pump photon and dc_photon
k_pump_in_pre_comp_slow = solve_refraction(k_pump_ext, 1, 1, pre_comp, lambda_pump, 1e-10, 100, 0, 1);
k_pump_in_pre_comp_fast = solve_refraction(k_pump_ext, 1, 2, pre_comp, lambda_pump, 1e-10, 100, 0, 1);

k_pump_in_1_slow = solve_refraction(k_pump_ext, 1, 1, dc_1, lambda_pump, 1e-10, 100, 0, 1);
k_pump_in_1_fast = solve_refraction(k_pump_ext, 1, 2, dc_1, lambda_pump, 1e-10, 100, 0, 1);
k_pump_in_2_fast = solve_refraction(k_pump_ext, 1, 2, dc_2, lambda_pump, 1e-10, 100, 0, 1);

k_dc1_in_1_slow = solve_refraction(k_dc_ext, 1, 1, dc_1, lambda_dc, 1e-10, 100, 0, 1);
k_dc1_in_2_fast = solve_refraction(k_dc_ext, 1, 2, dc_2, lambda_dc, 1e-10, 100, 0, 1);
k_dc2_in_2_slow = solve_refraction(k_dc_ext, 1, 1, dc_2, lambda_dc, 1e-10, 100, 0, 1);

k_dc1_in_spatial_comp_fast = solve_refraction(k_dc_ext, 1, 2, spatial_comp, lambda_dc, 1e-10, 100, 0, 1);
k_dc2_in_spatial_comp_slow = solve_refraction(k_dc_ext, 1, 1, spatial_comp, lambda_dc, 1e-10, 100, 0, 1);

%%%%%%%%%%%%%%%%spatial compensators
% group velocities of slow and fast dc photon in spatial compensator
[ignore, vg_dc1_in_spatial_comp_fast] = group_velocities(spatial_comp, lambda_pump, k_dc1_in_spatial_comp_fast);
[vg_dc2_in_spatial_comp_slow, ignore] = group_velocities(spatial_comp, lambda_pump, k_dc2_in_spatial_comp_slow);

[ignore, ignore, S_dc1_in_spatial_comp_fast] = phase(spatial_comp, lambda_dc, k_dc1_in_spatial_comp_fast, 'fast');
[ignore, ignore, S_dc2_in_spatial_comp_slow] = phase(spatial_comp, lambda_dc, k_dc2_in_spatial_comp_slow, 'slow');

phi_ext_spatial_comp = external_phase(spatial_comp, S_dc2_in_spatial_comp_slow, S_dc1_in_spatial_comp_fast, k_dc_ext, lambda_dc);
t_ext_spatial_comp = phi_ext_spatial_comp/(2*pi)*lambda_dc/(2.9979e14);

t_1_spatial_comp = spatial_comp.crystal_thickness/(vg_dc1_in_spatial_comp_fast*k_dc1_in_spatial_comp_fast(3));
t_2_spatial_comp = spatial_comp.crystal_thickness/(vg_dc2_in_spatial_comp_slow*k_dc2_in_spatial_comp_slow(3));

%%%%%%%%%%%%%%%%%%%%
% group velocities of slow and fast pump in first crystal
[vg_pump_in_1_slow, ignore] = group_velocities(dc_1, lambda_pump, k_pump_in_1_slow);
[ignore, vg_pump_in_1_fast] = group_velocities(dc_1, lambda_pump, k_pump_in_1_fast);

% group velocity of fast pump in second crystal
[ignore, vg_pump_in_2_fast] = group_velocities(dc_2, lambda_pump, k_pump_in_2_fast);

% slow group velocity in crystal 1 of photon born in crystal 1
[vg_dc1_in_1_slow, ignore] = group_velocities(dc_1, lambda_dc, k_dc1_in_1_slow);

% fast group velocity in crystal 2 of photon born in crystal 1
[ignore, vg_dc1_in_2_fast] = group_velocities(dc_2, lambda_dc, k_dc1_in_2_fast);

% slow group velocity in crystal 2 of photon born in crystal 2
[vg_dc2_in_2_slow, ignore] = group_velocities(dc_2, lambda_dc, k_dc2_in_2_slow);

% time at which signal photon generated in crystal 1 exits crystal 2
t_1_dc = dc_1.crystal_thickness*(0.5/(vg_pump_in_1_fast*k_pump_in_1_fast(3)) + 0.5/(vg_dc1_in_1_slow*k_dc1_in_1_slow(3))) + dc_2.crystal_thickness*1/(vg_dc1_in_2_fast*k_dc1_in_2_fast(3));

% time at which signal photon generated in crystal 2 exits crystal 2
t_2_dc = dc_1.crystal_thickness*1/(vg_pump_in_1_slow*k_pump_in_1_slow(3)) + dc_2.crystal_thickness*(0.5/(vg_pump_in_2_fast*k_pump_in_2_fast(3)) + 0.5/(vg_dc2_in_2_slow*k_dc2_in_2_slow(3)));

[ignore, ignore, S_dc1_in_1_slow] = phase(dc_1, lambda_dc, k_dc1_in_1_slow, 'slow');
[ignore, ignore, S_dc1_in_2_fast] = phase(dc_2, lambda_dc, k_dc1_in_2_fast, 'fast');
[ignore, ignore, S_dc2_in_2_slow] = phase(dc_2, lambda_dc, k_dc2_in_2_slow, 'slow');

phi_ext = external_phase_dc(dc_1, dc_2, lambda_dc, S_dc1_in_1_slow, S_dc1_in_2_fast, S_dc2_in_2_slow, k_dc_ext);
t_ext = phi_ext/(2*pi)*lambda_dc/(2.9979e14);

%%%%%%%%%%%%%%%%%%%%%%% pre-compensators
% group velocities of slow and fast pump in precompensator
[vg_pump_in_pre_comp_slow, ignore] = group_velocities(pre_comp, lambda_pump, k_pump_in_pre_comp_slow);
[ignore, vg_pump_in_pre_comp_fast] = group_velocities(pre_comp, lambda_pump, k_pump_in_pre_comp_fast);

[ignore, D_pump_in_1_fast, ignore] = phase(dc_1, lambda_dc, k_pump_in_1_fast, 'fast');
[ignore, D_pump_in_2_fast, ignore] = phase(dc_2, lambda_dc, k_pump_in_2_fast, 'fast');

[ignore, D_pump_in_pre_comp_slow, ignore] = phase(pre_comp, lambda_pump, k_pump_in_pre_comp_slow, 'slow');
[ignore, D_pump_in_pre_comp_fast, ignore] = phase(pre_comp, lambda_pump, k_pump_in_pre_comp_fast, 'fast');

a = dot(D_pump_in_1_fast, D_pump_in_pre_comp_slow);
b = dot(D_pump_in_1_fast, D_pump_in_pre_comp_fast);

if abs(a) > 0.9
    t_1_precomp = pre_comp.crystal_thickness*1/(vg_pump_in_pre_comp_slow*k_pump_in_pre_comp_slow(3));
    t_2_precomp = pre_comp.crystal_thickness*1/(vg_pump_in_pre_comp_fast*k_pump_in_pre_comp_fast(3));
elseif abs(b) > 0.9
    t_1_precomp = pre_comp.crystal_thickness*1/(vg_pump_in_pre_comp_fast*k_pump_in_pre_comp_fast(3));
    t_2_precomp = pre_comp.crystal_thickness*1/(vg_pump_in_pre_comp_slow*k_pump_in_pre_comp_slow(3));
else
    error('Orientation of pre-compensator is not optimal.')
end

delta_t_precomp = t_1_precomp - t_2_precomp;
delta_t_dc = t_1_dc - t_2_dc + t_ext;
delta_t_spatial_comp = t_1_spatial_comp - t_2_spatial_comp + t_ext_spatial_comp; 
delta_t_total = delta_t_precomp + delta_t_dc + delta_t_spatial_comp;

