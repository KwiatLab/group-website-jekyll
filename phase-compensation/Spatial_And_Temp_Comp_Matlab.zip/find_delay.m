function delay = find_delay(crystal_type,lambda,crystal_thickness)

% Outputs a vector containing the three principal indices of refraction for a particlar crystal
% The vector is of form [nx; ny; nz]
% lambda is in microns delay is in femtoseconds

global custom_crystals;
c=2.997*10^8;
if (crystal_type == 'BiBO')
    ne=1;
    no=1;
    x = bibo_principal_indices(lambda);
%elseif (crystal_type == 'BBO2')
%   x = [n_o_BBO(lambda); n_o_BBO(lambda); n_e_BBO(lambda)];
elseif (crystal_type == 'BBO1')
    no = sqrt(2.7359 + 0.01878/(lambda^2 - 0.01822) - 0.01354*lambda^2);

    ne = sqrt(2.3753 + 0.01224/(lambda^2 - 0.01667) - 0.01516*lambda^2);
     
    dno= 1/1000/(683975+4695/(lambda^2-911/50000)-3385*lambda^2)^(1/2)*(-9390/(lambda^2-911/50000)^2*lambda-6770*lambda);
    dne= 1/1000/(593825+3060/(lambda^2-1667/100000)-3790*lambda^2)^(1/2)*(-6120/(lambda^2-1667/100000)^2*lambda-7580*lambda);
    
    ngo= no - (lambda*dno);
    nge= ne - (lambda*dne);
    x=[subs(ngo, lambda),subs(ngo, lambda),subs(nge, lambda)];
    vgo=c/ngo;
    vge=c/nge;
    delay= crystal_thickness*(1/vgo-1/vge);
elseif (crystal_type == 'Quar')
    no = sqrt(2.6712295 + (-0.011090009)*lambda^2 + (-0.0001024662)*lambda^4 + 0.011838573/lambda^2 + (-0.31467511)*lambda^2*(lambda^2-0.018592511)/((lambda^2-0.018592511)^2 +0.015379669*lambda^2));
    ne = sqrt(2.6964507 + (-0.011596199)*lambda^2 + (-0.0001206215)*lambda^4 + 0.012383549/lambda^2 + (-0.31280678)*lambda^2*(lambda^2-0.019120036)/((lambda^2-0.019120036)^2 +0.015545792*lambda^2));  % Quartz

    dno= 1/17179869184/(197101947794572509184-818298231192542336*lambda^2-7560671070422151*lambda^4+873532505315711616/lambda^2-23218924882145603584*lambda^2*(lambda^2-2679463219567419/144115188075855872)/((lambda^2-2679463219567419/144115188075855872)^2+8865775561917641/576460752303423488*lambda^2))^(1/2)*(-1636596462385084672*lambda-30242684281688604*lambda^3-1747065010631423232/lambda^3-46437849764291207168*lambda*(lambda^2-2679463219567419/144115188075855872)/((lambda^2-2679463219567419/144115188075855872)^2+8865775561917641/576460752303423488*lambda^2)-46437849764291207168*lambda^3/((lambda^2-2679463219567419/144115188075855872)^2+8865775561917641/576460752303423488*lambda^2)+23218924882145603584*lambda^2*(lambda^2-2679463219567419/144115188075855872)/((lambda^2-2679463219567419/144115188075855872)^2+8865775561917641/576460752303423488*lambda^2)^2*(4*(lambda^2-2679463219567419/144115188075855872)*lambda+8865775561917641/288230376151711744*lambda));
    dne= 1/17179869184/(198962943881099902976-855648460723226496*lambda^2-8900295761147827*lambda^4+913744636508967424/lambda^2-23081066460724670464*lambda^2*(lambda^2-2755487584157135/144115188075855872)/((lambda^2-2755487584157135/144115188075855872)^2+4480769475736271/288230376151711744*lambda^2))^(1/2)*(-1711296921446452992*lambda-35601183044591308*lambda^3-1827489273017934848/lambda^3-46162132921449340928*lambda*(lambda^2-2755487584157135/144115188075855872)/((lambda^2-2755487584157135/144115188075855872)^2+4480769475736271/288230376151711744*lambda^2)-46162132921449340928*lambda^3/((lambda^2-2755487584157135/144115188075855872)^2+4480769475736271/288230376151711744*lambda^2)+23081066460724670464*lambda^2*(lambda^2-2755487584157135/144115188075855872)/((lambda^2-2755487584157135/144115188075855872)^2+4480769475736271/288230376151711744*lambda^2)^2*(4*(lambda^2-2755487584157135/144115188075855872)*lambda+4480769475736271/144115188075855872*lambda));
    
    ngo = no - (lambda*dno);
    nge = ne - (lambda*dne);
    x=[subs(ngo,lambda),subs(ngo,lambda),subs(nge,lambda)];    
    vgo=c/ngo;
    vge=c/nge;
    delay= abs(crystal_thickness*(1/vgo-1/vge))*1*10^12;
% custom pre-compensator crystal
%elseif (crystal_type == 'cst1')
 %   x = custom_n(custom_crystals.cst1, lambda);
    
% custom first DC crystal
%elseif (crystal_type == 'cst2')
%    x = custom_n(custom_crystals.cst2, lambda);
    
% custom second DC crystal
%elseif (crystal_type == 'cst3')
    %x = custom_n(custom_crystals.cst3, lambda);

% custom signal spatial comp crystal
%elseif (crystal_type == 'cst4')
    %x = custom_n(custom_crystals.cst4, lambda);

% custom idler spatial comp crystal
%elseif (crystal_type == 'cst5')
 %   x = custom_n(custom_crystals.cst5, lambda);    
    
else
    x = [1; 1; 1];
    ne=1;
    no=1;
end

