function answer = PropagateField;

% This function propagates an ultrashort pulse through an element using the
% brute force approach and then compares it to the grp velocity approach
clear
figfilename_root = 'Propagate E Field';
figfilename = [figfilename_root '.fig'];
%initialize variables

c=2.9979e14; %speed of light
% data_mark = ['-gs';'-bo';'-rd';'-kh';'-kx'];
data_mark = ['-g';'-b';'-r';'-k';'-c'];

pc_crystal='Quar'; %dispersive element
pctheta = 90; %units=degrees
pcphi = 0; %units=degrees
pcgamma = 0; %units=degrees
pctheta = pctheta*pi/180;                
pcphi = pcphi*pi/180;
pcgamma = pcgamma*pi/180;

npts=1000; %number of thicknesses of dispersive element to calculate
d=linspace(1, 10, npts); %thickness of dispersive element in mm
d=d*10^3;
time=linspace(1, 1000, npts);
lambda=405; %central wavelength in nm
delta_lambda=2.0; %spectral bandwidth in nm
lambda=lambda/10^3;
delta_lambda=delta_lambda/10^3;
nlambdas=100; %number of wavelengths to include in the discrete calculation

%Convert wavelength to frequency
lambda_width = delta_lambda/2;
lambda_center = lambda;
freq_center=c/lambda_center;
freq_low = c/(lambda_center + lambda_width);
freq_high = c/(lambda_center - lambda_width);
freq_array = linspace(freq_low, freq_high, nlambdas);
freq_width = freq_high - freq_low;
lambda_array = c./freq_array;


%find group velocity of the dispersive element.  We are using one
%polarization of a birefringent crystal because we already have the code
%for those.
k=[0;0;1];

E_group_slow=zeros(1,npts);
E_group_fast=zeros(1,npts);
E_brute_1=zeros(1,npts);
E_brute_2=zeros(1,npts);

%Polarization 2 is slow 

%Quartz lambda in microns

n_o = sqrt(2.6712295 + (-0.011090009)*lambda^2 + (-0.0001024662)*lambda^4 + 0.011838573/lambda^2 + (-0.31467511)*lambda^2*(lambda^2-0.018592511)/((lambda^2-0.018592511)^2 +0.015379669*lambda^2));  % Quartz
n_e = sqrt(2.6964507 + (-0.011596199)*lambda^2 + (-0.0001206215)*lambda^4 + 0.012383549/lambda^2 + (-0.31280678)*lambda^2*(lambda^2-0.019120036)/((lambda^2-0.019120036)^2 +0.015545792*lambda^2));  % Quartz

d=1;
for ii=1:npts
    pre_comp = set_crystal_param(pc_crystal, d, pctheta, pcphi, pcgamma);
    [vg_slow, vg_fast] = group_velocities(pre_comp, lambda_center, k);
   
    E_group_slow(ii)=real(exp(i*freq_center*time(ii))*exp(i*2*pi*freq_center*d/vg_slow));
    E_group_fast(ii)=real(exp(i*freq_center*time(ii))*exp(i*2*pi*freq_center*d/vg_fast));
    
    
     for jj=1:nlambdas
        f=freq_array(jj);
        lam=lambda_array(jj);
        % Get the principal indices of refraction for this crystal
        n_principal = get_n_principal(pc_crystal, lam);
        vp1(ii)=c/n_principal(3);
        vp2(ii)=c/n_principal(2);
        
 
        E_brute_1(ii)= E_brute_1(ii)+ exp(i*f*time(ii))*exp(i*2*pi*f*d/vp1(ii));
        E_brute_2(ii)=E_brute_1(ii)+ exp(i*f*time(ii))*exp(i*2*pi*f*d/vp2(ii));
     
     end
       
        E_brute_1(ii)= real(E_brute_1(ii))/nlambdas;
         E_brute_2(ii)= real(E_brute_2(ii))/nlambdas;
   
end   


   

d=d/10^3;
lambda=lambda*10^3;
delta_lambda=delta_lambda*10^3;


plot(time,E_brute_2,data_mark(2,:),time,E_group_fast,data_mark(3,:))

xlabel('time');
ylabel('Real E');
set(gca,'position',[0.15 0.1 0.8 0.7]); 
title({['E field propagation through quartz'];...
    [pc_crystal ' dispersive element, $\lambda =$ ' num2str(lambda)...
    ' nm, $\Delta\lambda =$ ' num2str(delta_lambda) ' nm, number of $\lambda$s = ' num2str(nlambdas)];...
    ['Filename = \verb+' figfilename_root '+']}, 'interpreter', 'latex');
legend('E_brute1','E_brute2','E_gf','E_gs','Location','EastOutside');
hgsave(figfilename)
c=fix(clock);
filename=[figfilename_root '_' num2str(c(1)) '-' num2str(c(2)) '-' num2str(c(3)) '-' num2str(c(4)) '-' num2str(c(5)) '-' num2str(c(6)) '.mat'];
save (filename)

