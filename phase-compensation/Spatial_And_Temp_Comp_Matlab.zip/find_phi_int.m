function x = find_phi_int(crystal_thickness, lambda, n, s_lab, poynting_vector)
% Calculates the acquired phase inside the crystal
% n is the refractive index one of the two polarization modes calculated
% based on s_crystal

% Crystal thickness and wavelength must have the same units

x = crystal_thickness*n*dot(s_lab, poynting_vector)*2*pi/(lambda*poynting_vector(3));




