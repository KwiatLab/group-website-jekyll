function n_o = n_o_KDP(lambda)

%returns the ordinary index of refraction for KDP at the specific wavelength in microns

n_o =  sqrt(2.259276 + 13.00522*lambda^2/(lambda^2 - 400) + 0.01008956/(lambda^2 - 77.26408^(-1)));    %% KDP
