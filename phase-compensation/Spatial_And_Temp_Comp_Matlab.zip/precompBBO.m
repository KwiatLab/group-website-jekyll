function [IrisSize,Tang,PhaseSlope_comp_x]= precompBBO(thickness);

% set basic parameters for dc from BBO at 351 nm with a cw pump at 3
% degrees cone and see variation with IRIS size. No spa comp.
pump = set_pump([cos(pi/4); sin(pi/4); 0], 1000, 1e9, 0.405, 0.000001);
dc_1 = set_crystal_param('BBO1', 600, 29.4*pi/180, 0, 0);
dc_2 = set_crystal_param('BBO1', 600, 29.4*pi/180, 0, pi/2);
filters = set_filters(0.810, 0.01, 0.810, 0.01, 3, 3)
irises = set_irises([0;63;1200], 0.5, [0;-63;1200], 0.5, 6, 6, 6, 6,1000)
custom_coeff=0;
plot_map=0;
comp_on=0;
pre_comp = set_crystal_param('Quar', thickness, pi/2, 0, pi/2);
comp_s = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, -pi/2);
comp_i = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, pi/2);

Tang=[];
PhaseSlope_x=[];
IrisSize=[];


lambda_pump_center = 0.405;
lambda_pump_width = 0.000286; %1/e width
lambda_pump_points = 11;

freq_pump_low = 1/(lambda_pump_center - lambda_pump_width);
freq_pump_high = 1/(lambda_pump_center + lambda_pump_width);
freq_pump_array = linspace(freq_pump_low, freq_pump_high, lambda_pump_points);

lambda_pump_array = 1./freq_pump_array;

    weight = exp(-(lambda_pump_array - lambda_pump_center).^2/(lambda_pump_width/2)^2);


comp_on = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rho_total = 0;

for k = 1: 1: lambda_pump_points
    pump = set_pump([cos(pi/4); sin(pi/4); 0], 1000, 1e9, lambda_pump_array(k), 0.000001);

    [rho, T, phases, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_v16g(irises, filters,...
pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff, plot_map);
    rho_total = rho_total + weight(k)*rho; 
end


rho = rho_total/trace(rho_total);

T = tangle(rho)



plot(IrisSize,Tang,'--rs','LineWidth',2,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',10)
           
               
                

           