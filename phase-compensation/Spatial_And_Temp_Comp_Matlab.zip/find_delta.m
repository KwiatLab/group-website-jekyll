function delta = find_delta(crystal_thickness, lambda, s_ext, S1, S2)


delta = 2*pi*crystal_thickness/lambda*(dot(S1, s_ext)/S1(3) - dot(S2, s_ext)/S2(3)); 