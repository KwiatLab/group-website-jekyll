function s_out = solve_refraction(s_in, n_in, n1_or_n2, crystal_param, lambda, tolerance, max_iterations, a, b);
% solves a multi-variable function by varying one parameter to zero.
% function_name must be another reachable function (.m file)
% a and b are variables to begin the search between
% tolerance is the tolerance between them
% max_iterations:  guess
% p1 through p5 are function_name's parameters.

% n1 corresponds to slow, n2 corresponds to fast

m_a = equation_to_minimize(a, crystal_param, lambda, n1_or_n2, s_in, n_in);
m_b = equation_to_minimize(b, crystal_param, lambda, n1_or_n2, s_in, n_in);
m = 2*tolerance;
i = 0;

while (i < max_iterations && abs(m) > tolerance)
    i = i + 1;
    s_out_tang = (a + b)/2;
    
    [m, s_out] = equation_to_minimize(s_out_tang, crystal_param, lambda, n1_or_n2, s_in, n_in);
   
    if (sign(m) == sign(m_a));
      m_a = m;
      a  = s_out_tang;
    else
      m_b = m;
      b  = s_out_tang;
    end
end 
%    m_abs = abs(m);
if  i == max_iterations
    disp(['solve_refraction did not converge within' num2str(max_iterations) 'iterations' 'abs(m) = ' num2str(abs(m))]);
end
end


