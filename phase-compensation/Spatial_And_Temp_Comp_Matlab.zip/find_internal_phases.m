% Calculates the phase acquired by light propagating through specified crystal for the two
% allowed polarization modes
function x = find_internal_phases(crystal_type, crystal_thickness, lambda, theta, phi, gamma, s_lab_int)

s_lab_int = s_lab_int/norm(s_lab_int);

% Transform propagation vector inside the crystal, s_lab_int, to crystal coordinates
s_crystal_int = transform_lab_to_crystal(s_lab_int, theta, phi, gamma);

% Get the principal indices of refraction for this crystal
n_principal = get_n_principal(crystal_type, lambda);

% Calculate the transformation matrix from the crystal coordinates to a coordinate system in 
% which s_crystal_int points in the [0;0;1] direction (called the s coordinates)
crystal_to_s_coord = crystal_to_s_coord_matrix(s_crystal_int);

% Calculate the transverse permeability matrix in the s coordinates (see function for more
% details)
eta_transverse = get_eta_transverse(n_principal, crystal_to_s_coord);

% Calculate the fast and slow indices of refraction corresponding to propagation vector, s
n1_and_n2 = find_n1_and_n2(eta_transverse);

n1 = n1_and_n2(1)
n2 = n1_and_n2(2)

% Calculate the directions of the two allowed polarization modes corresponding to s
% Vectors are in the crystal coordinates
D_eigenvectors = find_D_eigenvectors(eta_transverse, crystal_to_s_coord);

D1_crystal = D_eigenvectors(:, 1);
D2_crystal = D_eigenvectors(:, 2);

% Transform D vectors to lab coordinates
D1_lab = transform_crystal_to_lab(D1_crystal, theta, phi, gamma)
D2_lab = transform_crystal_to_lab(D2_crystal, theta, phi, gamma)

% Calculate the eletric field directions for the polarization modes in the direction s
% Electric field vectors are, in genereal, not parallel to displacement vectors, D
E_eigenvectors = find_E_eigenvectors(n_principal, D_eigenvectors);

E1_crystal = E_eigenvectors(:, 1);
E2_crystal = E_eigenvectors(:, 2);

% Transform E-field vectors to lab coordinates
E1_lab = transform_crystal_to_lab(E1_crystal, theta, phi, gamma);
E2_lab = transform_crystal_to_lab(E2_crystal, theta, phi, gamma);

% Calculate the Poynting vectors for the two polarization modes
S1_crystal = find_poynting_vector(s_crystal_int, E1_crystal);
S2_crystal = find_poynting_vector(s_crystal_int, E2_crystal);

% Transform Poynting vectors to lab coordinates
S1_lab = transform_crystal_to_lab(S1_crystal, theta, phi, gamma);
S2_lab = transform_crystal_to_lab(S2_crystal, theta, phi, gamma);

% Check that D1, D2 and s are all mutually orthogonal in the lab frame, as they should be
D1_dot_D2 = dot(D1_lab, D2_lab)
s_lab_int_dot_D1_lab = dot(s_lab_int, D1_lab)
s_lab_int_dot_D2_lab = dot(s_lab_int, D2_lab)

crystal_z_axis_lab = transform_crystal_to_lab([0;0;1], theta, phi, gamma)
n_bar = cross(crystal_z_axis_lab, s_lab_int)
n_bar = n_bar/norm(n_bar);
D1_dot_z_axis = dot(n_bar, D1_lab)
D2_dot_z_axis = dot(n_bar, D2_lab)

% Calculate the total acuired phase in the crystal by the two polarization modes with
% propagation direction s
phi1 = find_phi_int(crystal_thickness, lambda, n1, s_lab_int, S1_lab);
phi2 = find_phi_int(crystal_thickness, lambda, n2, s_lab_int, S2_lab);

x = [phi1; phi2];
