function [phi0, D_lab, S_lab, n] = phase(crystal_param, lambda, s_lab_int, slow_or_fast);

crystal_type = crystal_param.crystal_type;
thickness= crystal_param.crystal_thickness;
theta = crystal_param.theta;
phi = crystal_param.phi;
gamma = crystal_param.gamma;

if slow_or_fast == 'slow'
    slow_or_fast = 1;
elseif slow_or_fast == 'fast'
    slow_or_fast = 2;
end

s_lab_int = s_lab_int/norm(s_lab_int);

% Transform propagation vector inside the crystal, s_lab_int, to crystal coordinates
s_crystal = transform_lab_to_crystal(s_lab_int, theta, phi, gamma);

% Get the principal indices of refraction for this crystal
n_principal = get_n_principal(crystal_type, lambda);

% Calculate the transformation matrix from the crystal coordinates to a coordinate system in 
% which s_crystal_int points in the [0;0;1] direction (called the s coordinates)
crystal_to_s_coord = crystal_to_s_coord_matrix(s_crystal);

% Calculate the transverse permeability matrix in the s coordinates (see function for more
% details)
eta_transverse = get_eta_transverse(n_principal, crystal_to_s_coord);

% Calculate the fast and slow indices of refraction corresponding to propagation vector, s
n_slow_and_n_fast = find_n1_and_n2(eta_transverse);
n = n_slow_and_n_fast(slow_or_fast); 

% Calculate the directions of the two allowed polarization modes corresponding to s
% Vectors are in the crystal coordinates
D_eigenvectors = find_D_eigenvectors(eta_transverse, crystal_to_s_coord);
D_crystal = D_eigenvectors(:, slow_or_fast);

% Transform D vectors to lab coordinates
D_lab = transform_crystal_to_lab(D_crystal, theta, phi, gamma);

% Calculate the eletric field directions for the polarization modes in the direction s
% Electric field vectors are, in genereal, not parallel to displacement vectors, D
E_eigenvectors = find_E_eigenvectors(n_principal, D_eigenvectors);

E_crystal = E_eigenvectors(:, slow_or_fast);

% Transform E-field vectors to lab coordinates
E_lab = transform_crystal_to_lab(E_crystal, theta, phi, gamma);

% Calculate the Poynting vectors for the two polarization modes
S_crystal = find_poynting_vector(s_crystal, E_crystal);

% Transform Poynting vectors to lab coordinates
S_lab = transform_crystal_to_lab(S_crystal, theta, phi, gamma);

% Calculate the total acquired phase in the crystal by the two polarization modes with
% propagation direction s
phi0 = find_phi_int(thickness, lambda, n, s_lab_int, S_lab);