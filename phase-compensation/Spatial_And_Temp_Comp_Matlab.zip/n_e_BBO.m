function n_e = n_e_BBO(lambda)

%returns the extraordinary index of refraction for BBO at the specific wavelength in microns

n_e = sqrt(2.3730 + 0.0128/(lambda^2 - 0.0156) - 0.0044*lambda^2);    %% BBO
