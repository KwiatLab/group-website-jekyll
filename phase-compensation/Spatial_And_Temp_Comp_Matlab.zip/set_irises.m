function irises = set_irises(center_s, radius_s, center_i, radius_i, N_sx, N_sy, N_ix, N_iy, pump_w)

%NOTE: pump_w is in microns and the iris radii are in mm

% all iris positions and radii are in mm

% calculate array of position points on the signal-side iris
irises.s_x_array = linspace(center_s(1) - (radius_s-pump_w/1000), center_s(1) + (radius_s-pump_w/1000), N_sx);
irises.s_y_array = linspace(center_s(2) - (radius_s-pump_w/1000), center_s(2) + (radius_s-pump_w/1000), N_sy);
;
% calculate array of position points on the idler-side iris
irises.i_x_array = linspace(center_i(1) - (radius_i-pump_w/1000), center_i(1) + (radius_i-pump_w/1000), N_ix);
irises.i_y_array = linspace(center_i(2) - (radius_i-pump_w/1000), center_i(2) + (radius_i-pump_w/1000), N_iy);

irises.center_s = center_s;
irises.radius_s = radius_s;
irises.center_i = center_i;
irises.radius_i = radius_i;
irises.N_sx = N_sx;
irises.N_sy = N_sy;
irises.N_ix = N_ix;
irises.N_iy = N_iy;

