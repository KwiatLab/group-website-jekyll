function x = transform_crystal_to_lab(crystal_vector, theta, phi, gamma)

% This function transforms an [x;y;z] vector from the lab reference frame
% to the crystal reference frame by rotation through polar angle theta and
% azimuthal angle phi

% theta and phi are the angles of rotation going from crystal frame to lab
% frame
% theta = acos(cos(theta));

crystal_vector=crystal_vector/norm(crystal_vector);

crystal_to_lab_rot_matrix = [cos(theta)*cos(phi) cos(theta)*sin(phi) -sin(theta);
                             -sin(phi) cos(phi) 0;
                             sin(theta)*cos(phi) sin(theta)*sin(phi) cos(theta)];
                         
inv_z_lab_rotation_matrix = [cos(gamma) -sin(gamma) 0;
                         sin(gamma) cos(gamma) 0;
                         0 0 1];

x = inv_z_lab_rotation_matrix*crystal_to_lab_rot_matrix*crystal_vector;