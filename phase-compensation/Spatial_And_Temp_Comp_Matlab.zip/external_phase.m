function phi_external = external_phase(crystal_param, S_1, S_2, s_ext, lambda)

thickness = crystal_param.crystal_thickness;

position_1 = thickness*S_1/S_1(3);
position_2 = thickness*S_2/S_2(3);

position_dist = norm(position_2 - position_1);

phi_external = 2*pi/lambda*position_dist*dot(normalize(position_2 - position_1), s_ext);
