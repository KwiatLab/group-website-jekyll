function filters = set_filters(lambda_s_center, width_s, lambda_i_center, width_i, N_sf, N_if)

% all wavelengths and widths are in microns

% create array of signal wavelengths that fall in the signal filter pass band
% wavelength points must be equally spaced in frequency space, not wavelength space
freq_s_low = 1/(lambda_s_center - width_s/2);
freq_s_high = 1/(lambda_s_center + width_s/2);
freq_s_array = linspace(freq_s_low, freq_s_high, N_sf);
filters.lambda_s_array = 1./freq_s_array;

% create array of idler wavelengths that fall in the idler filter pass band
freq_i_low = 1/(lambda_i_center - width_i/2);
freq_i_high = 1/(lambda_i_center + width_i/2);
freq_i_array = linspace(freq_i_low, freq_i_high, N_if);
filters.lambda_i_array = 1./freq_i_array;

filters.lambda_s_center = lambda_s_center;
filters.width_s = width_s;
filters.lambda_i_center = lambda_i_center;
filters.width_i = width_i;
filters.N_sf = N_sf;
filters.N_if = N_if;