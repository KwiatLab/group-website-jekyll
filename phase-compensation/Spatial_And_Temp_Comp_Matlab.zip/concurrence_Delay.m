function Tang=concurrence_Delay(rho,CoherenceTime, Delay)
% Usage: C=concurrence(rho)
%
% Returns the two-qubit concurrence of the density matrix rho or a
% two qubit state.
Tang=[];
PRecomp=[];
IdealDelay=0;

%Delay= find_delay('Quar',0.405,thickness);


 rho(1,4)=rho(1,4)*exp(-(abs(IdealDelay-abs(Delay))/CoherenceTime)^2);
  rho(4,1)=rho(4,1)*exp(-(abs(-abs(IdealDelay-Delay))/CoherenceTime)^2);
    if(min(size(rho)) == 1)
	rho = psi * psi';
    end
  Z = [0 0 0 -1; 0 0 1 0; 0 1 0 0; -1 0 0 0];
  R = rho * Z * rho.' * Z;
  [right,r]=eig(R);
  %left = inv(right);
  r=real(diag(r));
  tmp = sort(sqrt(r));
  C = real(tmp(4) - tmp(3) - tmp(2) - tmp(1));
  C = max(C, 0);
 Tang=C^2;


