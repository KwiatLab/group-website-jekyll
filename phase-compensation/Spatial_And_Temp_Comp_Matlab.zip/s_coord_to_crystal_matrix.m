function m = s_coord_to_crystal_matrix(s_crystal)

% Creates matrix for the coordinate transformation between an s vector in
% crystal coordinate system to the "s" coordinate system
% In the "s" coordinate system the s vector has the form [0; 0; 1]

x = s_crystal(1);
y = s_crystal(2);
z = s_crystal(3);

theta = acos(z/sqrt(x^2+y^2+z^2));
phi = atan(y/x);

m = [cos(theta)*cos(phi) -sin(phi) sin(theta)*cos(phi); 
                             cos(theta)*sin(phi) cos(phi) sin(theta)*sin(phi);
                             -sin(theta) 0 cos(theta)];