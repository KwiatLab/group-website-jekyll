function [CompAngle,Tang,PhaseSlope_comp_x]=SpaCompAngle_BBO_3();

% set basic parameters for dc from BBO at 405 nm with a cw pump at 3
% degrees cone and see variation of phase addded by a spa comp of length 30
% micron with the cut angle. 

pump = set_pump([cos(pi/4); sin(pi/4); 0], 1000, 1e9, 0.405, 0.000001);
dc_1 = set_crystal_param('BBO1', 600,29.3*pi/180, 0, 0);
dc_2 = set_crystal_param('BBO1', 600, 29.3*pi/180, 0, pi/2);
filters = set_filters(0.810, 0.01, 0.810, 0.01, 3, 3)
irises = set_irises([0;63;1200], 5, [0;-63;1200], 5, 6, 6, 6, 6,1000)
custom_coeff=0;
plot_map=0;
comp_on=1;
pre_comp = set_crystal_param('Quar', 0, pi/2, 0, pi/2);
comp_s = set_crystal_param('BBO1', 245, 29.3*pi/180, 0, -pi/2);
comp_i = set_crystal_param('BBO1', 245, 29.3*pi/180, 0, pi/2);

Tang=[];

CompAngle=[];
PhaseSlope_comp_x=[];


for theta = 10: 10 :360

  comp_s = set_crystal_param('BBO1',300 , theta*pi/180, 0, -pi/2);
  comp_i = set_crystal_param('BBO1',300, theta*pi/180, 0, pi/2);
  [rho, T, phases, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_v16g(irises, filters,...
  pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff, plot_map)
  Tang(theta/10)=T;
   
  CompAngle(theta/10)= theta;
  PhaseSlope_comp_x(theta/10)= phases.comp_x_slope;
end

plot(CompAngle,Tang,'--rs','LineWidth',2,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',10)
           
                        
                

