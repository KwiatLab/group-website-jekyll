function n_e = n_e_KDP(lambda)

%returns the extraordinary index of refraction for KDP at the specific wavelength in microns

n_e = sqrt(2.132668 + 3.2279924*lambda^2/(lambda^2 - 400) + 0.008637494/(lambda^2 - 81.42631^(-1)));    %% KDP
