function [Tang,PrecompLength]=BBOprecomp1();

% set basic parameters for dc from BBO at 405 nm with a cw pump at 3
% degrees cone and see variation with precomp length. No spa comp. Correct
% orientation of precomp is gamma =pi/2
pump = set_pump([cos(pi/4); sin(pi/4); 0], 1000, 1e9, 0.405, 0.004);
dc_1 = set_crystal_param('BBO1', 600, 29.3*pi/180, 0, 0);
dc_2 = set_crystal_param('BBO1', 600, 29.3*pi/180, 0, pi/2);
filters = set_filters(0.810, 0.01, 0.810, 0.01, 3, 3);
irises = set_irises([0;63;1200], 1, [0;-63;1200], 1, 6, 6, 6, 6,1000);
custom_coeff=0;
plot_map=0;
comp_on=0;
pre_comp = set_crystal_param('BBO1', 0, pi/2, 0, pi/2);
comp_s = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, -pi/2);
comp_i = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, pi/2);

Tang=[];

PrecompLength=[];




for j =1500:100:2500
  PrecompLength((j/100-14))=j;
  pre_comp = set_crystal_param('BBO1', j, pi/2, 0, pi/2);

  [rho, T, phases, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_v16g(irises, filters,...
  pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff, plot_map);
  
  Tang(j/100-14)=T;

end

plot(PrecompLength,Tang,'--rs','LineWidth',2,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',10)
           
               
                


           