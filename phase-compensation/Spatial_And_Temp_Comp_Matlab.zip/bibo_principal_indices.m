function indices = bibo_principal_indices(lambda)

% returns a vector containing the principal indices of refraction for BiBO
% indices are sorted because by definition, n_z > n_y > n_x
% Sellmeier coeff. are obtained from the Newlight photonics website
% http://www.newlightphotonics.com/bibo-properties.html

n1 = sqrt(3.6545 + 0.0511/(lambda^2 - 0.0371) - 0.02260*lambda^2);
n2 = sqrt(3.0740 + 0.0323/(lambda^2 - 0.0316) - 0.01337*lambda^2); 
n3 = sqrt(3.1685 + 0.0373/(lambda^2 - 0.0346) - 0.01750*lambda^2);

indices = sort([n1; n2; n3]);

end