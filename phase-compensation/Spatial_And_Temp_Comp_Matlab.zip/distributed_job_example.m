%After installing the CCS local utilities and modifying your config file to reflect your user
%settings, start up Compute Cluster Job Manager and run this script from the Matlab command line.
%You will be asked for your Active Directory credentials - enter your
%username and password.  Your job details will be displayed in the Matlab
%stdout window and the job will appear in the Job Queue.  When it has
%finished successfully, it will display 'job finished'.  
clear all
%clc
% sched=findResource('scheduler','type','mpiexec','lookupURL', 'ece-hpc-01.ece.uiuc.edu')
sched=findResource('scheduler', 'configuration', 'ccs')
set(sched,'configuration','local')
job=createJob(sched);
T = createTask(job, @rand, 1, {{3,3},{3,3},{3,3},{3,3},{3,3}});
get(sched)
sched;
submit(job)
waitForState(job)
results=getAllOutputArguments(job);
results{1:5}

errmsgs=get(job.Tasks,{'ErrorMessage'});
nonempty=~cellfun(@isempty,errmsgs);
celldisp(errmsgs(nonempty));

job_state='Job finished.';
job_state

destroy(job);
clear job;