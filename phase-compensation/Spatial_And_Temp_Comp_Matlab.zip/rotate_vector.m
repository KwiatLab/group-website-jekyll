function r = rotate_vector(p, n_bar, rho)

% This function rotates the vector p ([x;y;z]) about the vector n_bar by rho radians
if (norm(n_bar) == 0)
    
    r = p;
    
else
    
  n_bar = n_bar / norm(n_bar);

  r = p * cos(rho) + n_bar * dot(n_bar, p)*(1-cos(rho)) + cross(n_bar, p) * sin(rho);
  
end
