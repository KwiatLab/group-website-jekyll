function n_o = n_o_LI(lambda)

%returns the ordinary index of refraction for Lithium Iodate at the specific wavelength in microns

n_o = sqrt(3.4132 + 0.0476/(lambda^2 - 0.0338) - 0.0077*lambda^2);    %% LI
