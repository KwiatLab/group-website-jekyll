function check2()

check=844