function filters = set_filters_mm(lambda_s_center, width_s, lambda_i_center, width_i, N_sf, N_if)

no_modes_s = length(lambda_s_center);
no_widths_s = length(width_s);
if no_modes_s ~= no_widths_s
    disp('The number of signal bandwidths must match the number of signal wavelengths.')
end
no_modes_i = length(lambda_i_center);
no_widths_i = length(width_i);
if no_modes_i ~= no_widths_i
    disp('The number of idler bandwidths must match the number of idler wavelengths.')
end
% all wavelengths and widths are in microns

% create array of signal wavelengths that fall in the signal filter pass band
% wavelength points must be equally spaced in frequency space, not wavelength space
for j_mode=1:1:no_modes_s
freq_s_low(j_mode) = 1/(lambda_s_center(j_mode) - width_s(j_mode)/2);
freq_s_high(j_mode) = 1/(lambda_s_center(j_mode) + width_s(j_mode)/2);
freq_s_array(j_mode,:) = linspace(freq_s_low(j_mode), freq_s_high(j_mode), N_sf);
filters.lambda_s_array(j_mode,:) = 1./freq_s_array(j_mode,:);

% create array of idler wavelengths that fall in the idler filter pass band
freq_i_low(j_mode) = 1/(lambda_i_center(j_mode) - width_i(j_mode)/2);
freq_i_high(j_mode) = 1/(lambda_i_center(j_mode) + width_i(j_mode)/2);
freq_i_array(j_mode,:) = linspace(freq_i_low(j_mode), freq_i_high(j_mode), N_if);
filters.lambda_i_array(j_mode,:) = 1./freq_i_array(j_mode,:);
end
filters.lambda_s_center = lambda_s_center;
filters.width_s = width_s;
filters.lambda_i_center = lambda_i_center;
filters.width_i = width_i;
filters.N_sf = N_sf;
filters.N_if = N_if;