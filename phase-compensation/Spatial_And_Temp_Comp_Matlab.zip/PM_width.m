function width = PM_width(R, w, lambda)


for j = 1: 1: 100

z = 1000*(j-.999);
k = 2*pi/lambda;

z0 = w0^2*pi/lambda;
R = z*(1+(z0/z)^2);
w = w0*(1+(z/z0)^2)^.5;

width(j) = 1/(sqrt(1/z^2*w^2/(4+w^4/R^2)));
position(j) = z/1000;
end

plot(position, width);