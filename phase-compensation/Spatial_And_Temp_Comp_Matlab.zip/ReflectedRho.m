function [T, ref_rho]=ReflectedRho(rho,r)

% returns the tangle and the new density matrix of the incoherent sum of
% the original density matrix and the reflected original density matrix. r
% is the reflection in percentage of the crystal. 

r1=r/100;
ref_rho=abs(rho) + (r1^2)*(1-r1)*abs(rho);
T=tangle(ref_rho);