function [rho, T, phases, irises, param] = PHASEMAP_AND_RHO(irises, filters,...
pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the top level function for the Type-I entangled photon source simulation. The main output of this function is the 4x4
% density matrix representing the two-photon polarization state of the system and a phasemap of the signal-side iris. The 
% calculation takes into account the phases acquired by the pump, signal and idler photons as they propagate through the down-conversion
% crystals. The effect of spatial phase-compensation crystals and temporal precompensation crystals is also calculated. 
% (For a description of the spatial phase-compensation method, see the paper by Altepeter et al. [1])
% 
% The sequence of the calculation is as follows:
%   1. Choose a signal photon having k-vector that falls inside the  collection iris and a wavelength passed by the frequency filter
%   2. If the distibution of idler photon k-vectors for this signal photon is large relative to spacing between points on the idler
%      iris (which is determined by the k-vector content of the pump beam), then pick any idler k-vector and frequency that fall in the
%      idler iris and filter. If the idler distribution is small (i.e. narrow angular range), then find the one idler direction 
%      corresponding to the signal photon by conservation of momentum.
%   3. Propagate the pump through the precompensation crystal to find the phases it acquires
%   3. Find the polarization modes, k-vectors, and Poynting vectors of signal and idler photons in each the first and second
%      down-conversion crystals
%   4. Find the phase acquired by each photon in the crystals in the two possible processes: (1) down-conversion occured in the first
%      crystal and (2) down-conversion occured in the second crystal
%   5. Propagate signal and idler photons through phase-compensation crystals as in steps 3-4 by finding polarization modes,
%      k-vectors, Poynting vectors and phases.
%   6. By taking a superposition of the two down-conversion processes, find the pure polarization state that describes the signal 
%      and idler photons
%   7. Repeat the above procedure for all k-vectors and wavelengths that are collected by the irises and filters
%   8. Incoherently sum all of the pure density matrices to get the overall density matrix
%
% COORDINATE SYSTEM:
% All crystal surfaces are in the xy-plane. For example, if the pump beam is normal to the down-conversion crystals, then it
% has the momentum unit vector [0;0;1]. The parameters of the down-conversion and phase-compensation crystals (the cut angles 
% theta and phi) are set using the convention of Beouf et al. [2] (see set_crystal_param.m for more details on setting crystal 
% parameters). 
%
% DESCRIPTION OF INPUTS:
% irises: a structure containing the parameters of the two circular irises that collect the signal and idler photons
%         - the radius, 3D position of the iris center, and the number of x and y points to calculate for each iris can be set using
%           set_irises.m (see notes for that function for more details)
%         - the irises are assumed to be in the xy-plane
%         - all iris parameters in units of millimeters
% filters: a structure containing the parameters of the two frequency filters for the signal and idler photons
%          - the central wavelength, the filter bandwidth, and the number points to calculate can be set for each iris using
%            set_filters.m (see notes of that function for more details)
%          - the transmission for all wavelengths within the bandwidth is assumed to be 100%
%          - all filter parameters in units of micrometers
% dc_1: a structure containing the parameters of the first down-conversion crystal (the one closest to the pump laser)
% dc_2: a structure containing the parameters of the second down-conversion crystal (the one farthest from the pump laser)
% pre_comp: a structure containing the parameters of the temporal precompensation crystal
% comp_s: a structure containing the parameters of the phase-compensation crystal for the signal photons
% comp_i: a structure containing the parameters of the phase-compensation crystal for the idler photons
%       - parameters for each crystal are set using set_crystal_param.m
%       - to add a new crystal type open get_n_principal and add a new case
% pump: structure containing the parameters of the pump beam and is set using set_pump.m
% comp_on: set to 1 if phase compensation crystals (compensators) should be used in calculation, or 0 otherwise
% custom_coeff is an array contaning the Sellemeir coefficients of a custom crystal (i.e. one that does not have its own case in
%        get_n_principal.m) Each row contains the four coefficients for a particular axis in the crystal, and there are three rows.
%
% KEY ASSUMPTIONS/APPROXIMATIONS MADE IN THE SIMULATION:
% - Type-I down-conversion is a fast=>slow-slow process (fast photon down-converts into two slow photons).
%   (See Boeuf et al. [2] for more details)
% - Pump beam is a Gaussian
% - The two down-conversion crystals are thin, so that the two down-conversion process can be considered indistinguishable
% - The surfaces of down-conversion and compensation crystals are all in the xy-plane and the crystals have no wedge
% - The signal and idler frequency filters have 100% transmission for wavelengths that fall in the pass band
% - Loss due to reflections at crystal surfaces is ignored
%
% NOTE: Some of the lower level functions are not well commented yet, but will be in future versions.
% 
% - all wavelengths are in free space 
% - to add a new crystal type, open get_n_principal.m and add a new case
%
% REFERENCES:
% [1] J. B. Altepeter, et al. "Phase-compensated ultra-bright source of entangled photons," Optics Express, 13, 8951-8959 (2005).
% [2] N. Boeuf, et al. "Calculating characteristics of noncollinear phase matching in uniaxial and biaxial 
%     crystals," Opt. Eng. 39: 1016-1024 (2000).
% [3] A. Joobeur, B. E. A. Saleh, et al. "Coherence properties of entangled light beams generated by parametric
% down-conversion: theory and experiment," Phys. Rev. A, 53: 4360-4371 (1996).
% [4] A. Yariv and P. Yeh, Optical Waves in Crystals, Wiley, 1984.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global custom_crystals 
custom_crystals = custom_coeff;

slow_flips=zeros(1,9);
fast_flips=zeros(1,9);
dc_flips=zeros(1,4);
flip_slow=0;
flip_fast=0;
flip_dc=0;

% the spectral width will be defined as 1/2 of the 1/e full width (i.e. 1 stdev) 
lambda_pump_width = pump.lambda_width/2;
lambda_pump_center = pump.lambda_center;
freq_pump_low = 1/(lambda_pump_center - lambda_pump_width/2);
freq_pump_high = 1/(lambda_pump_center + lambda_pump_width/2);
freq_pump_array = linspace(freq_pump_low, freq_pump_high, filters.N_if);
freq_pump_width = freq_pump_high - freq_pump_low;
lambda_pump_array = 1./freq_pump_array;

% old version of last two lines
% freq_pump_width = lambda_pump_width/((lambda_pump_center + lambda_pump_width)*(lambda_pump_center - lambda_pump_width));
% lambda_pump_array = linspace(lambda_pump_center - lambda_pump_width, lambda_pump_center + lambda_pump_width, filters.N_if); 

% pump is always in the z-direction
% "k_pump_in_1" means the unit k-vector of the pump in DC crystal 1
k_pump_ext = [0;0;1];
k_pump_in_1 = [0;0;1];
k_pump_in_2 = [0;0;1];

if irises.N_ix > 1 && irises.N_iy > 1
    i_x_inc = abs(irises.i_x_array(1) - irises.i_x_array(2));
    i_y_inc = abs(irises.i_y_array(1) - irises.i_y_array(2));
else
    i_x_inc = 1e10;
    i_y_inc = 1e10;
end
    
% aprroximate width of idler photon spatial distribution on the idler iris from one signal k-vector
modified_width = sqrt(abs(pump.R*pump.w^2/(4*pump.R+2*i*2*pi*1.6/lambda_pump_center*pump.w^2)));
idler_width = filters.lambda_i_center/1000*irises.center_i(3)/(1.6*modified_width/1000)/2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%I am not sure why this code is in here nor why it would be useful to
%randomly sample the idler iris independently of the signal iris so I took
%this out.  -MG
% if idler_width < 2*i_x_inc && idler_width < 2*i_y_inc  
%     N_ix = 1;
%     N_iy = 1;
%     do_idler_iris = 0;
% else
%     N_ix = irises.N_ix;
%     N_iy = irises.N_iy;
%     do_idler_iris = 1;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    N_ix = 1;
    N_iy = 1;
    do_idler_iris = 0;  
    
total_points = irises.N_sx*irises.N_sy*N_ix*N_iy*filters.N_sf*filters.N_if;

Dnp_s1_in_1_slow = [0; 0; 0];
Dnp_s1_in_2_slow = [0; 0; 0];
Dnp_s1_in_2_fast = [0; 0; 0];
Dnp_i1_in_1_slow = [0; 0; 0];
Dnp_i1_in_2_slow = [0; 0; 0];
Dnp_i1_in_2_fast = [0; 0; 0];
Dnp_s2_in_2_slow = [0; 0; 0];
Dnp_i2_in_2_slow = [0; 0; 0];

Dnp_s1_in_precomp_slow = [0; 0; 0];
Dnp_s1_in_precomp_fast = [0; 0; 0];
Dnp_s2_in_precomp_slow = [0; 0; 0];
Dnp_s2_in_precomp_fast = [0; 0; 0];
Dnp_i1_in_precomp_slow = [0; 0; 0];
Dnp_i1_in_precomp_fast = [0; 0; 0];
Dnp_i2_in_precomp_slow = [0; 0; 0];
Dnp_i2_in_precomp_fast = [0; 0; 0];

% initialize arrays
rho =[0 0 0 0;0 0 0 0;0 0 0 0;0 0 0 0];
dc_phase = 0;
comp_phase = 0;
a = 0;
%phases = 0;
I = 0;
N = 0;
for j_sf = 1: 1: filters.N_sf
for j_if = 1: 1: filters.N_if
for j_sx = 1: 1: irises.N_sx
for j_sy = 1: 1: irises.N_sy
for j_ix = 1: 1: N_ix
for j_iy = 1: 1: N_iy

    N = N + 1;
    
    lambda_s = filters.lambda_s_array(j_sf);
    lambda_pump = lambda_pump_array(j_if);
    % using conservation of energy among the pump, signal, and idler photons, compute wavelength of idler photon
    lambda_i = 1/(1/lambda_pump - 1/lambda_s);
    lambda_i_array(j_sf,j_if)=lambda_i;
    
    pump_lambdas=[lambda_pump lambda_pump_center-lambda_pump lambda_pump_width];
    if lambda_pump_width < 1e-10 && abs(lambda_pump_center-lambda_pump) < 1e-10
        pump_spect_weight = 1;
    elseif lambda_pump_width < 1e-10
        pump_spect_weight = 0;
	else
        pump_spect_weight = exp(-((1/lambda_pump - 1/lambda_pump_center)/freq_pump_width)^2);
    end
    
    % find external (in free space) k-vector for some (x,y,z) position on the signal-side iris
    k_s_ext = normalize([irises.s_x_array(j_sx); irises.s_y_array(j_sy); irises.center_s(3)]);
    
    if do_idler_iris == 0
        % find the angle between the signal and pump k-vectors
        beta_s_ext = acos(dot(k_s_ext, k_pump_ext));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % The purpose of the following section is to find the external k-vector of the idler photon such that the momentum
        % mismatch between the three photons is minimized inside the crystals.
        
        % find the k-vectors of signal photon in each DC crystal (correspond to slow polarization)
        % the notation k_s1_in_1 means: the k-vector of the signal photon born in the first crystal, propagating in the first crystal
		k_s1_in_1 = solve_refraction(k_s_ext, 1, 1, dc_1, lambda_s, 1e-10, 100, 0, 1);
		k_s2_in_2 = solve_refraction(k_s_ext, 1, 1, dc_2, lambda_s, 1e-10, 100, 0, 1);
        
        % find the angle between signal and pump k-vectors in each DC crystal
        beta_s1_in_1 = acos(dot(k_s1_in_1, k_pump_in_1));
        beta_s2_in_2 = acos(dot(k_s2_in_2, k_pump_in_2));
        
        % the angle between pump the idler k-vectors can be approximated by the transverse momentum conservation condition:
        %    n_s/lambda_s*sin(beta_s) = n_i/lambda_i*sin(beta_i)
        % the refractive indices n_s and n_i are approximately equal, so the approximate relation for beta_i is:
        %    beta_i = beta_s*lambda_i/lambda_s
        % the approximate beta_i will be used as a guess in calculating the exact angle later 
        beta_i1_in_1_approx = -beta_s1_in_1*lambda_i/lambda_s;
        beta_i2_in_2_approx = -beta_s2_in_2*lambda_i/lambda_s;
        
        % set the angle tolerance for finding the exact beta_i in each crystal
        % the tolerance must be small because the phasematching function is sharply peaked and the minimization process
        % will not converge unless a tight bounds are supplied
        tol = 0.1*pi/180;
        % find the exact beta_i in each crystal by minimizing the phasematching function
        % the input to the phasematching function is the momentum mismatch between the pump, signal and idler photons:
        %    delta_k = k_pump*n_pump/lambda_pump - k_s*n_s/lambda_s - k_i*n_i/lambda_i
        % the phasematching function returns 0 when delta_k = 0 (perfect phasematching) and approaches 1 for large delta_k
        % the approximate beta_i angles are used to set the range of angles to search within
        % fminbnd returns the lowest value of the phasematching function and corresponding beta_i
        % see paper by Beouf et al. [2] for more details on phasematching function
        
        options = optimset('MaxIter', 100, 'TolFun', 1e-4);
        %changed Ria
        [beta_i1_in_1, PM_1, exitflg1] = fminbnd(@(beta_i1_in_1) evaluate_weighting_func_for_search(beta_i1_in_1, dc_1, pump.w, lambda_pump, lambda_s, k_pump_in_1, k_s1_in_1, pump.R),...
             beta_i1_in_1_approx - tol, beta_i1_in_1_approx + tol,  options );
        [beta_i2_in_2, PM_2, exitflg2] = fminbnd(@(beta_i2_in_2) evaluate_weighting_func_for_search(beta_i2_in_2, dc_2, pump.w, lambda_pump, lambda_s, k_pump_in_2, k_s2_in_2, pump.R),...
             beta_i2_in_2_approx - tol, beta_i2_in_2_approx + tol,  options );

%         [beta_i1_in_1, PM_1, exitflg1] = fminbnd(@evaluate_weighting_func_for_search, beta_i1_in_1_approx - tol, beta_i1_in_1_approx + tol, [], dc_1, pump.w, lambda_pump, lambda_s, k_pump_in_1, k_s1_in_1, pump.R);
%         [beta_i2_in_2, PM_2, exitflg2] = fminbnd(@evaluate_weighting_func_for_search, beta_i2_in_2_approx - tol, beta_i2_in_2_approx + tol, [], dc_2, pump.w, lambda_pump, lambda_s, k_pump_in_2, k_s2_in_2, pump.R);
%         PM=[PM_1 PM_2 exitflg1 exitflg2];
        
            
%         beta=[beta_i1_in_1 beta_i2_in_2]
        
        % W_1 and W_2 are the unnormalized probabilities of each down-conversion process occuring
        % these two values will be close to 1 if phasematching conditions are met
        % checking W_1 and W_2 is a good test of whether all inputs and crystal parameters were set correctly
        % and that down-conversion is in fact occuring
       %Commented out Ria
        PM_1 =1 - PM_1;
       PM_2 = 1 - PM_2;
%          PM_1 = -PM_1;
%          PM_2 = -PM_2;		
        % using beta_i angles, find k-vectors of idler photon in each crystal
        k_i1_in_1 = rotate_vector(k_pump_in_1, cross(k_pump_in_1, k_s1_in_1), beta_i1_in_1);
		k_i2_in_2 = rotate_vector(k_pump_in_2, cross(k_pump_in_2, k_s2_in_2), beta_i2_in_2);
		
		% find the slow refractive indices of for idler k-vector  
        [n_i1_in_1, temp] = find_n1_and_n2_top(dc_1, lambda_i, k_s1_in_1);
        [n_i2_in_2, temp] = find_n1_and_n2_top(dc_2, lambda_i, k_s2_in_2);
        % refract idler k-vectors from crystal into free space
        % the external idler k-vector will be approximated to be the same whether down-conversion occured in 
        % the first or second crystal. Both external vectors will be calculated but only the external k-vector corresponding
        % down-conversion in the first crystal will be used. The angle diff_k_i_ext can be used to check if k_i_ext_1 and 
        % k_i_ext_2 are the same.
		k_i_ext_1 = refraction_in_xy_plane(k_i1_in_1, n_i1_in_1, 1);
        k_i_ext_2 = refraction_in_xy_plane(k_i2_in_2, n_i2_in_2, 1);
        diff_k_i_ext = acos(dot(k_i_ext_1, k_i_ext_2));
        if abs(diff_k_i_ext) > 10^(-3)
            disp(['diff_k_i_ext = ' num2str(diff_k_i_ext)])
        end
        k_i_ext = k_i_ext_1; % see notes above for explanation
        
    elseif do_idler_iris == 1
        k_i_ext = normalize([irises.i_x_array(j_ix); irises.i_y_array(j_iy); irises.center_i(3)]);
    
        % find the k-vectors of signal photon in each DC crystal (correspond to slow polarization)
        % the notation k_s1_in_1 means: the k-vector of the signal photon born in the first crystal, propagating in the first crystal
		k_s1_in_1 = solve_refraction(k_s_ext, 1, 1, dc_1, lambda_s, 1e-10, 100, 0, 1);
		k_s2_in_2 = solve_refraction(k_s_ext, 1, 1, dc_2, lambda_s, 1e-10, 100, 0, 1);
		
        k_i1_in_1 = solve_refraction(k_i_ext, 1, 1, dc_1, lambda_i, 1e-10, 100, 0, 1);
		k_i2_in_2 = solve_refraction(k_i_ext, 1, 1, dc_2, lambda_i, 1e-10, 100, 0, 1);
        %changed Ria
        PM_1 = evaluate_weighting_func(dc_1, pump.w, lambda_pump, lambda_s, lambda_i, k_pump_ext, k_s1_in_1, k_i1_in_1, pump.R);
        PM_2 = evaluate_weighting_func(dc_2, pump.w, lambda_pump, lambda_s, lambda_i, k_pump_ext, k_s2_in_2, k_i2_in_2, pump.R);
    end
    
    
%phi_pump_precomp_slow and _fast are the phases picked up by polarizations
%in the slow and fast directions, respectively.  D_pump_precomp_slow and
%_fast are the corresponding polarizations. -MG
    
    [phi_pump_precomp_slow, D_pump_precomp_slow] = phase(pre_comp, lambda_pump, [0;0;1], 'slow');
    [phi_pump_precomp_fast, D_pump_precomp_fast] = phase(pre_comp, lambda_pump, [0;0;1], 'fast');
    
    [ignore, ignore, phi_pump_in_1_fast, ignore, Dnp_pump_in_1_fast, flip_slow, flip_fast] = propagate_crystal_14([0;1;0], k_pump_ext, lambda_pump, dc_1, [0;0;0], [0;0;0]);
    slow_flips(1)=slow_flips(1) + flip_slow;
    fast_flips(1)=fast_flips(1) + flip_fast;
    
    [ignore, ignore, phi_pump_in_1_slow, Dnp_pump_in_1_slow, ignore, flip_slow, flip_fast] = propagate_crystal_14([1;0;0], k_pump_ext, lambda_pump, dc_1, [0;0;0], [0;0;0]);
    slow_flips(2)=slow_flips(2) + flip_slow;
    fast_flips(2)=fast_flips(2) + flip_fast;

    [ignore, ignore, phi_pump_in_2_fast, ignore, Dnp_pump_in_2_fast, flip_slow, flip_fast] = propagate_crystal_14([1;0;0], k_pump_ext, lambda_pump, dc_2, [0;0;0], [0;0;0]);
    slow_flips(3)=slow_flips(3) + flip_slow;
    fast_flips(3)=fast_flips(3) + flip_fast;

  
    
    phi_pump_in_1_fast = 1/2*phi_pump_in_1_fast;
 	phi_pump_in_2_fast = 1/2*phi_pump_in_2_fast;
    
    dc_in_1_intensity = dot(pump.D, Dnp_pump_in_1_fast)^2;
    dc_in_2_intensity = dot(pump.D, Dnp_pump_in_2_fast)^2;
    
    if abs(dot(D_pump_precomp_slow, Dnp_pump_in_1_fast)) > 0.9
        phi_dc_1_precomp = phi_pump_precomp_slow;
        phi_dc_2_precomp = phi_pump_precomp_fast;
    else
        phi_dc_1_precomp = phi_pump_precomp_fast;
        phi_dc_2_precomp = phi_pump_precomp_slow;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Propagate signal photon born in the first crystal through half the first crystal and all of the second
    % propagate_dc_crystal_14.m calculates the slow polarization vector inside the DC crystal, applies the phase
    % acquired by propagating through half of the crystal, and refracts the polarization vector from the crystal into
    % free space. The outputs are:
    % D_s1_after_1 is the polarization vector of the signal photon born in the first crystal after exiting the first crystal
    % S_s1_in_1_slow is the Poynting vector of the signal photon in the first crystal
    % phi_s1_in_1_slow is the phase acquired by the signal photon by propagating through half of the first crystal
    [D_s1_after_1, S_s1_in_1_slow, phi_s1_in_1_slow, Dnp_s1_in_1_slow, flip_dc] = propagate_dc_crystal_14(k_s_ext, lambda_s, dc_1, Dnp_s1_in_1_slow);
    dc_flips(1)=dc_flips(1)+ flip_dc;
  
    % propagate_crystal_14.m has the same function as propagate_dc_crystal_14.m except that it propagates the photon through
    % the entire length of the second crystal starting with the polarization vector exiting the first crystal  
    [D_s1_after_2, S_s1_in_2_fast, phi_s1_in_2_fast, Dnp_s1_in_2_slow, Dnp_s1_in_2_fast, flip_slow, flip_fast] = propagate_crystal_14(D_s1_after_1, k_s_ext, lambda_s, dc_2, Dnp_s1_in_2_slow, Dnp_s1_in_2_fast);
    slow_flips(4)=slow_flips(4) + flip_slow;
    fast_flips(4)=fast_flips(4) + flip_fast;

    % repeat procedure above for the idler photon
    [D_i1_after_1, S_i1_in_1_slow, phi_i1_in_1_slow, Dnp_i1_in_1_slow, flip_dc] = propagate_dc_crystal_14(k_i_ext, lambda_i, dc_1, Dnp_i1_in_1_slow);
    dc_flips(2)=dc_flips(2)+ flip_dc;
    
    [D_i1_after_2, S_i1_in_2_fast, phi_i1_in_2_fast, Dnp_i1_in_2_slow, Dnp_i1_in_2_fast, flip_slow, flip_fast] = propagate_crystal_14(D_i1_after_1, k_i_ext, lambda_i, dc_2, Dnp_i1_in_2_slow, Dnp_i1_in_2_fast);
    slow_flips(5)=slow_flips(5) + flip_slow;
    fast_flips(5)=fast_flips(5) + flip_fast;

    % propagate signal and idler photons born in the second crystal through half of the second crystal
    [D_s2_after_2, S_s2_in_2_slow, phi_s2_in_2_slow, Dnp_s2_in_2_slow, flip_dc] = propagate_dc_crystal_14(k_s_ext, lambda_s, dc_2, Dnp_s2_in_2_slow);
    dc_flips(3)=dc_flips(3)+ flip_dc;
    
    [D_i2_after_2, S_i2_in_2_slow, phi_i2_in_2_slow, Dnp_s2_in_2_slow, flip_dc] = propagate_dc_crystal_14(k_i_ext, lambda_i, dc_2, Dnp_s2_in_2_slow);
    dc_flips(4)=dc_flips(4)+ flip_dc;

    % calculate external phase after down conversion crystals
    % the external phase results from the fact that photons born in the first crystal exit the second crystal at a
    % different point than those born in the second crystal (see supplemental file for more details)
    phi_ext_dc_s = external_phase_dc(dc_1, dc_2, lambda_s, S_s1_in_1_slow, S_s1_in_2_fast, S_s2_in_2_slow, k_s_ext);
    phi_ext_dc_i = external_phase_dc(dc_1, dc_2, lambda_i, S_i1_in_1_slow, S_i1_in_2_fast, S_i2_in_2_slow, k_i_ext);
    
    % add external phase to the photons from crystal 1
    D_s1_after_2 = D_s1_after_2*exp(i*phi_ext_dc_s);
    D_i1_after_2 = D_i1_after_2*exp(i*phi_ext_dc_i);
    
    % calculate absolute phase acquired by each of the photons
    dc_phase_s1(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = phi_s1_in_1_slow + phi_s1_in_2_fast + phi_ext_dc_s;
    dc_phase_s2(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = phi_s2_in_2_slow;
    dc_phase_i1(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = phi_i1_in_1_slow + phi_i1_in_2_fast + phi_ext_dc_i;
    dc_phase_i2(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = phi_i2_in_2_slow;
    
    % find the phase difference between two-photon states from the first and second DC crystals
    dc_phase(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = (dc_phase_s2(j_sx, j_sy, j_ix, j_iy, j_sf, j_if)...
        + dc_phase_i2(j_sx, j_sy, j_ix, j_iy, j_sf, j_if)) - (dc_phase_s1(j_sx, j_sy, j_ix, j_iy, j_sf, j_if)...
        + dc_phase_i1(j_sx, j_sy, j_ix, j_iy, j_sf, j_if));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Propagate the four photons through the phase-compensation crystals
    % Same procedure as for DC crystals, except that all photons propagate through the entire crystal
    if comp_on == 1
        
        [D_s1_after_comp, S_s1_in_comp, phi_s1_in_comp, Dnp_s1_in_precomp_slow, Dnp_s1_in_precomp_fast, flip_slow, flip_fast] = propagate_crystal_14(D_s1_after_2, k_s_ext, lambda_s, comp_s, Dnp_s1_in_precomp_slow, Dnp_s1_in_precomp_fast);
        slow_flips(6)=slow_flips(6) + flip_slow;
        fast_flips(6)=fast_flips(6) + flip_fast;

        [D_s2_after_comp, S_s2_in_comp, phi_s2_in_comp, Dnp_s2_in_precomp_slow, Dnp_s2_in_precomp_fast, flip_slow, flip_fast] = propagate_crystal_14(D_s2_after_2, k_s_ext, lambda_s, comp_s, Dnp_s2_in_precomp_slow, Dnp_s2_in_precomp_fast);
        slow_flips(7)=slow_flips(7) + flip_slow;
        fast_flips(7)=fast_flips(7) + flip_fast;

        [D_i1_after_comp, S_i1_in_comp, phi_i1_in_comp, Dnp_i1_in_precomp_slow, Dnp_i1_in_precomp_fast, flip_slow, flip_fast] = propagate_crystal_14(D_i1_after_2, k_i_ext, lambda_i, comp_i, Dnp_i1_in_precomp_slow, Dnp_i1_in_precomp_fast);
        slow_flips(8)=slow_flips(8) + flip_slow;
        fast_flips(8)=fast_flips(8) + flip_fast;

        [D_i2_after_comp, S_i2_in_comp, phi_i2_in_comp, Dnp_i2_in_precomp_slow, Dnp_i2_in_precomp_fast, flip_slow, flip_fast] = propagate_crystal_14(D_i2_after_2, k_i_ext, lambda_i, comp_i, Dnp_i2_in_precomp_slow, Dnp_i2_in_precomp_fast);
        slow_flips(9)=slow_flips(9) + flip_slow;
        fast_flips(9)=fast_flips(9) + flip_fast;
        
        phi_ext_comp_s = external_phase(comp_s, S_s1_in_comp, S_s2_in_comp, k_s_ext, lambda_s);
        phi_ext_comp_i = external_phase(comp_i, S_i1_in_comp, S_i2_in_comp, k_i_ext, lambda_i);
        
        D_s1_after_comp = exp(i*phi_ext_comp_s)*D_s1_after_comp;
        D_i1_after_comp = exp(i*phi_ext_comp_i)*D_i1_after_comp;
        
        % find the difference in the phases acquired by s1-i1 and s2-i2 pairs in the compensation crystals
        comp_phase(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = (phi_s2_in_comp + phi_i2_in_comp) - (phi_s1_in_comp + phi_i1_in_comp + phi_ext_comp_s + phi_ext_comp_i);
    else
        D_s1_after_comp = D_s1_after_2;
        D_i1_after_comp = D_i1_after_2;
        D_s2_after_comp = D_s2_after_2;
        D_i2_after_comp = D_i2_after_2;
        comp_phase(j_sx, j_sy, j_ix, j_iy, j_sf, j_if) = 0;
    end
    
%     pump_spect_weight;
%     test_array(j_sx, j_sy) = abs(PM_1)^2;
    I = I + pump_spect_weight*abs(PM_1)^2;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% set the basis in which the photon state will be measured
    % assume that measurements are made using polarizers whose plane is perpendicular to the central k-vector
    
    % set axes for signal-side polarizer
    % assume that polarizer axis is in the x-direction
    V_s = [1;0;0];
	% Z_s is the vector normal to the polarizer 
    Z_s = normalize(irises.center_s);
	% find the second basis vector
    H_s = cross(V_s, Z_s);
	
	% set axes for idler-side polarizer
    V_i = [1;0;0];
	Z_i = normalize(irises.center_i);
	H_i = cross(V_i, Z_i);
	
	% construct matrices that will transform the photon polarization vectors into the measurement basis
    M_s = [H_s, V_s, Z_s];
	M_i = [H_i, V_i, Z_i];
    
    % transform polarization vectors into the measurement basis
    psi_s1 = normalize(M_s*D_s1_after_comp);
    psi_i1 = normalize(M_i*D_i1_after_comp);
    psi_s2 = normalize(M_s*D_s2_after_comp);
    psi_i2 = normalize(M_i*D_i2_after_comp);
    
    % find the two-photon polarization state for pair born in first crystal and second crystal by taking the tensor product
    % of the one-photon states (2-component polarization vectors in the measurement basis)
    psi_1 = normalize(kron(psi_s1(1:2), psi_i1(1:2)));
	psi_2 = normalize(kron(psi_s2(1:2), psi_i2(1:2)));
    
    % the two-photon pure state is a weighted linear superposition of the two-photon states from each crystal
    % the weights are the DC intensities (from the phasematching function) that were found earlier
    % the four components of the state are (VV, VH, HV, HH), where V is polarization in x direction (perpendicular to
    % table) and H is parallel to the polarizer and in the plane of the table
    psi = (sqrt(dc_in_1_intensity)*PM_1*psi_1 + sqrt(dc_in_2_intensity)*PM_2*psi_2*exp(i*(phi_pump_in_2_fast + phi_pump_in_1_slow - phi_pump_in_1_fast + phi_dc_2_precomp - phi_dc_1_precomp)))*pump_spect_weight;

    % find the distance between the point where each photon is incident on the iris and the center of the iris 
    s_dist(j_sf,j_if,j_sx,j_sy,j_ix,j_iy) = norm(k_s_ext/k_s_ext(3)*irises.center_s(3) - irises.center_s);
    i_dist(j_sf,j_if,j_sx,j_sy,j_ix,j_iy) = norm(k_i_ext/k_i_ext(3)*irises.center_i(3) - irises.center_i);
            
    % check that signal and idler photons are in the range of their respective iris and add the pure density matrix
    % to the total density matrix
  if s_dist(j_sf,j_if,j_sx,j_sy,j_ix,j_iy) <= irises.radius_s && i_dist(j_sf,j_if,j_sx,j_sy,j_ix,j_iy) <= irises.radius_i
      a = a + 1;
         rho = rho + psi*psi';
  end
  
phi_ext_dc_s_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_ext_dc_s;
phi_ext_dc_i_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_ext_dc_i;
phi_pump_1_fast_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_pump_in_1_fast;
phi_pump_1_slow_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_pump_in_1_slow;
phi_pump_2_fast_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_pump_in_2_fast;
phi_pump_pc_1_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_dc_1_precomp;
phi_pump_pc_2_array(j_sf,j_if,j_sx,j_sy,j_ix,j_iy)=phi_dc_2_precomp;

end
end
end 
end
end
end

if any(any(rho > [1e-10 1e-10 1e-10 1e-10; 1e-10 1e-10 1e-10 1e-10; 1e-10 1e-10 1e-10 1e-10; 1e-10 1e-10 1e-10 1e-10]))
    % normalize the density matrix to have unity trace
    rho = rho/trace(rho);

    % construct pure state with which overlap will be taken to get the state fidelity
    phi_pure = angle(rho(1,4));
    rho_pure = [rho(1,1) 0 0 sqrt(rho(1,1)*rho(4,4))*exp(i*phi_pure); 
            0 0 0 0; 
            0 0 0 0; 
            sqrt(rho(1,1)*rho(4,4)*exp(-i*phi_pure)) 0 0 rho(4,4)];
    % compute overlap between pure state and actual state
    F = fidelity(rho, rho_pure);
    T = tangle(rho);
else
    rho=[0 0 0 0;0 0 0 0;0 0 0 0;0 0 0 0];
    T=0;
    F=0;
end
% find the x and y slopes of the phasemaps in degrees/mm
[dc_x_slope, dc_y_slope] = phasemap_slope(dc_phase(:, :, 1, 1, 1, 1), irises.s_x_array, irises.s_y_array);

if comp_on == 1
    total_phase = dc_phase + comp_phase;
    [comp_x_slope, comp_y_slope] = phasemap_slope(comp_phase(:, :, 1, 1, 1, 1), irises.s_x_array, irises.s_y_array);
	[total_x_slope, total_y_slope] = phasemap_slope(total_phase(:, :, 1, 1, 1, 1), irises.s_x_array, irises.s_y_array);
else
    total_phase = dc_phase;
    comp_x_slope = 0;
    comp_y_slope = 0;
    [total_x_slope, total_y_slope] = phasemap_slope(total_phase(:, :, 1, 1, 1, 1), irises.s_x_array, irises.s_y_array);
end

irises.dist_s=s_dist;
irises.dist_i=i_dist;

param.lambda_pump=lambda_pump_array;
param.lambda_signal=filters.lambda_s_array;
param.lambda_idler=lambda_i_array;
param.iris_hits=a;
param.max_hits=total_points;

phases.phi_ext_s_dc=phi_ext_dc_s_array;
phases.phi_ext_i_dc=phi_ext_dc_i_array;
phases.phi_pump_1_fast=phi_pump_1_fast_array;
phases.phi_pump_1_slow=phi_pump_1_slow_array;
phases.phi_pump_2_fast=phi_pump_2_fast_array;
phases.phi_pump_pc_1=phi_pump_pc_1_array;
phases.phi_pump_pc_2=phi_pump_pc_2_array;
phases.dc_s1=dc_phase_s1;
phases.dc_s2=dc_phase_s2;
phases.dc_i1=dc_phase_i1;
phases.dc_i2=dc_phase_i2;
phases.dc=dc_phase;    
phases.total_phase = total_phase;
phases.x_array = irises.s_x_array;
phases.y_array = irises.s_y_array;
phases.dc_x_slope = dc_x_slope;
phases.dc_y_slope = dc_y_slope;
phases.comp_x_slope = comp_x_slope;
phases.comp_y_slope = comp_y_slope;
phases.total_x_slope = total_x_slope;
phases.total_y_slope = total_y_slope;

%surfl(irises.s_x_array, irises.s_y_array, total_phase(:, :, 1, 1, 1, 1))
%colormap(autumn)
%xlabel('X, mm', 'fontsize', 18)
%ylabel('Y, mm', 'fontsize', 18)
%zlabel('Phi, degrees', 'fontsize', 18)







