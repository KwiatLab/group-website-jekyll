function d_eff = d_eff_BiBO(theta, phi, lambda)

theta = theta*pi/180;
phi = phi*pi/180;
indices = bibo_principal_indices(lambda);
n_x=indices(1);
n_y=indices(2);
n_z=indices(3);
omega = asin(n_z/n_y*sqrt((n_y^2 - n_x^2)/(n_z^2 - n_x^2)));
arg=(cot(omega)^2*sin(theta)^2 - cos(theta)^2*cos(phi)^2 + sin(phi)^2)/(sin(2*phi)*cos(theta));
delta = 0.5*acot(arg);
% if abs(delta) < 1e-10
%     delta = 0;
% end

%Nonlinear coefficient tensor for b=x from (Ghotbi, 2004) p.6981
d=[2.53, 2.93, -1.93, 1.63, 0, 0; 0, 0, 0, 0, 1.67, 3.48; 0, 0, 0, 0, -1.58, 1.67];

%Calculate d_eff using equation from(Tzankov, 2005) p.6981
d_eff =  -(d(1,1)*cos(phi)^2 + 3*d(1,2)*sin(phi)^2)*cos(theta)^3*cos(phi)*sin(delta)*cos(delta)^2 ...
        -(d(1,1)*sin(phi)^2 + d(1,2)*(3*cos(phi)^2-2))*cos(theta)*cos(phi)*sin(delta)^3 ...
        +2*(d(1,1)*sin(phi)^2 - d(1,2)*(3*sin(phi)^2 - 1))*cos(theta)*cos(phi)*sin(delta)*cos(delta)^2 ...
        +2*(d(1,1)*cos(phi)^2 - d(1,2)*(3*cos(phi)^2 - 1))*cos(theta)^2*sin(phi)*sin(delta)^2*cos(delta) ...
        -(d(1,1)*cos(phi)^2 - d(1,2)*(3*cos(phi)^2 - 1))*cos(theta)^2*sin(phi)*cos(delta)^3 ...
        -(d(1,1)*sin(phi)^2 + 3*d(1,2)*cos(phi)^2)*sin(phi)*sin(delta)^2*cos(delta) ...
        -d(1,3)*sin(theta)^2*cos(delta)*(3*cos(theta)*cos(phi)*sin(delta)*cos(delta) ...
        + sin(phi)*(3*cos(delta)^2 - 2)) ...
        +d(1,4)*(sin(2*theta)*cos(2*phi)*cos(delta)*(3*sin(delta)^2 - 1)...
        + sin(theta)*sin(2*phi)*sin(delta)*(3*cos(theta)^2*cos(delta)^2 + 3*cos(delta)^2 - 1));

%General equation for d_eff for type I phase matching (incomplete, see eq 8
%p. 6975 of (Tzankov, 2005))

%(Note that Tzankov refers to the paper: Tzankov, Pancho and
%Valentin Petrov, "Effective second-order nonlinearity in  accentric
%optical crystals", Applied Optics 44, 6971-6985 (2005) and Ghotbi refers
%to Ghotbi M. and M. Ebrahim-Zadeh, "Optical harmonic generation properti.s
%of BiB_3O_6", Optics Express 12, 6002 (2004).)
%d_eff = -(d(1,1)*cos(phi)^3 + 3*d(1,2)*sin(phi)^2*cos(phi) + 3*d(1,6)*sin(phi)*cos(phi)^2 + d(2,2)*sin(phi)^3

end