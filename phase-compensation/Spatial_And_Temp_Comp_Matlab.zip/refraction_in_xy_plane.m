function s_out = refraction_in_xy_plane(s_in, n_in, n_out)

s_in = s_in/norm(s_in);

x_in = s_in(1);
y_in = s_in(2);
z_in = s_in(3);

if (s_in == [0;0;1])
    s_out = [0;0;1];
else
    x_out = n_in/n_out*x_in;
    y_out = n_in/n_out*y_in;
    z_out = sqrt(1 - x_out^2 - y_out^2);

    s_out = [x_out; y_out; z_out]; 
end
end