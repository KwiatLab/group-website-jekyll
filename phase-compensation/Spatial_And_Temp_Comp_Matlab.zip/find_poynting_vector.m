function x = find_poynting_vector(s_crystal, E_vector)
% s_crystal and E_vector are unit vectors in crystal coordinates

% The constants associated with the Poynting vector are ignored
% See Yariv and Yeh for derivation
poynting_vector = s_crystal - E_vector*dot(s_crystal, E_vector);

x = poynting_vector/norm(poynting_vector);




