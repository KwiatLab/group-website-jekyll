function indices = BBO_ref1_principal_indices(lambda)
% These seem to be the most reliable/accurate values.
% These are the values used by Newlight Photonics.
% These correspond to BBO Ref. 1 in the NIST Phasematch program and
% are given in Dmitriev, et al, Handbook of Nonlinear Optical
% Crystals, Third Revised Edition (Springer, NY 1999) p.99.

n1 = sqrt(2.7359 + 0.01878/(lambda^2 - 0.01822) - 0.01354*lambda^2);
n2 = n1;
n3 = sqrt(2.3753 + 0.01224/(lambda^2 - 0.01667) - 0.01516*lambda^2);

indices = [n1; n2; n3];