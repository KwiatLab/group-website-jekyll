function x = find_D_eigenvectors(eta_transverse, crystal_to_s_coord_matrix)

% This function finds the directions of the two allowed polarizations (displacement vectors) given
% eta_transverse which is in the s coordinate system
% see Yariv and Yeh, Chapter 4, for explanation of this process

% Finds eigenvlues and eigenvectors of eta_transverse

% eta_transverse must be rounded because, if left unrounded, the eigenvectors exhibit chaotic sign flipping
% (meaning that the polarization vector gets flipped 180 degrees for some eta_transverse but not for other, almost identical,
% eta_transverse.)
%eta_transverse = 1e-7*round(eta_transverse*1e7);

%[V,D] = eig(eta_transverse);
[V,D] = eig(eta_transverse);
%condest(V);

% Extracts the two D eigenvectors in the s coordinate system
D1_transformed = V(:, 1);
D2_transformed = V(:, 2);

% Add a zero z component to each eigenvector (D1 and D2 are perpendicular
% to s vector which is in the z direction, in the s coordinate system)
D1_transformed_3D = [D1_transformed(1); D1_transformed(2); 0];
D2_transformed_3D = [D2_transformed(1); D2_transformed(2); 0];

% Transform back to the crystal coordinates
D1 = inv(crystal_to_s_coord_matrix)*D1_transformed_3D;
D2 = inv(crystal_to_s_coord_matrix)*D2_transformed_3D;

n1 = 1/sqrt(D(1,1));
n2 = 1/sqrt(D(2,2));

if (n1 < n2)
    D1_temp = D1;
    D2_temp = D2;
    D1 = D2_temp;
    D2 = D1_temp;
end
x = [D1 D2];

%(eta_transverse - [1 0; 0 1].*D(1,1))

