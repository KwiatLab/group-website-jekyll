function x = transform_lab_to_crystal_test_wrapper()

% This function transforms an [x;y;z] vector from the lab reference frame
% to the crystal reference frame by rotation through polar angle theta and
% azimuthal angle phi

% theta and phi are the angles of rotation going from crystal frame to lab
% frame

s_lab_int = [0; 0; 1]
s_lab_int = s_lab_int/norm(s_lab_int);
s_lab = s_lab/norm(s_lab);

lab_to_crystal_rot_matrix = [cos(theta)*cos(phi)  -sin(phi) sin(theta)*cos(phi);
                            cos(theta)*sin(phi) cos(phi) sin(theta)*sin(phi);
                            -sin(theta) 0 cos(theta)];
                         
z_lab_rotation_matrix = [cos(gamma) sin(gamma) 0;
                         -sin(gamma) cos(gamma) 0;
                         0 0 1];

x = lab_to_crystal_rot_matrix*z_lab_rotation_matrix*s_lab;
x = transform_lab_to_crystal(s_lab, theta, phi, gamma)
