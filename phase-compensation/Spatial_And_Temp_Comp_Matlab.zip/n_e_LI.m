function n_e = n_e_LI(lambda)

%returns the extraordinary index of refraction for Lithium Iodate at the specific wavelength in microns

n_e = sqrt(2.9211 + 0.0346/(lambda^2 - 0.0320) - 0.0042*lambda^2);    %% LI
