function x = biaxial_angle_vs_lambda_wrapper_2007_8_21_1818
%commented out to run in batch mode
figfilename_root = 'biaxial_angle_vs_lambda_wrapper_2007_8_21_1818';
figfilename = [figfilename_root '.fig'];

tic
disp('Initialize parameters')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

crystals = ['BBO1';'BiBO'];
d = [600, 600];
data_mark = ['-c';'-m';'-r';'-g';'-b';'-k'];
nlambdas =250;
lambda = linspace(380, 880, nlambdas); %units=nm
lambda = lambda/1000;

n_crystals=length(d);
format compact

disp('Begin calculation')

% for jj=1:1:n_crystals
%     disp(['Calculating ' num2str(jj) ' of ' num2str(n_crystals) ' crystals calculated.'])
   for kk=1:1:nlambdas
        x = get_n_principal(crystals(2,:),lambda(kk));
    for ii=1:1:3
    index(kk,ii) = x(ii);
    end
    psi(kk) = asin((index(kk,3)*sqrt((index(kk,2)^2-index(kk,1)^2)))/(index(kk,2)*sqrt(index(kk,3)^2-index(kk,1)^2)));
disp(['Point ' num2str(kk) ' of ' num2str(nlambdas) ' points calculated.'])
   end
%end


c=fix(clock);
filename=[figfilename_root '_' num2str(c(1)) '-' num2str(c(2)) '-' num2str(c(3)) '-' num2str(c(4)) '-' num2str(c(5)) '-' num2str(c(6)) '.mat'];
save (filename)


plot(lambda(:)*1000, psi(:)*180/pi, data_mark(4,:));
title(['Angle between optic axis and z-axis (V_z) vs. wavelength for ' crystals(2,:)]);
xlabel('\lambda (nm)');
ylabel('V_z (^\circ)');
%legend(['n_3 ' crystals(2,:)], ['n_2 ' crystals(2,:)], ['n_1 ' crystals(2,:)],['n_1 ' crystals(1,:)], ['n_2 ' crystals(1,:)], ['n_3 ' crystals(1,:)]);
hgsave(figfilename);


calctime=toc;

disp(['Calculation took ' num2str(calctime) ' seconds'])


end