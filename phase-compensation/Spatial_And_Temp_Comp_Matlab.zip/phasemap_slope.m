function [x_slope, y_slope] = phasemap_slope(phase_array, x_positions, y_positions)

x_points = size(x_positions, 2);
y_points = size(y_positions, 2);

x_slope = 180/pi*(phase_array(round(x_points/2), x_points) - phase_array(round(x_points/2), 1))/(x_positions(x_points) - x_positions(1));
y_slope = 180/pi*(phase_array(y_points, round(y_points/2)) - phase_array(1, round(y_points/2)))/(y_positions(y_points) - y_positions(1));


