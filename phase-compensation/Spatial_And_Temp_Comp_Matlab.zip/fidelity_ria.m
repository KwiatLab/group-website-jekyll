function [F]=fidelity_ria(rho)

% gives the fidelity of a 4*4 density matrix with HH+VV or rho_comp and
% 


    
    rho_comp = 0.5*[1 0 0 1;0 0 0 0;0 0 0 0; 1 0 0 1];

    F= real((trace((rho^0.5 *rho_comp * rho^0.5)^0.5))^2);
    