function n_o = n_o_quartz(lambda)

%returns the ordinary index of refraction for quartz at the specific wavelength in microns

n_o = sqrt(2.6712295 + (-0.011090009)*lambda^2 + (-0.0001024662)*lambda^4 + 0.011838573/lambda^2 + (-0.31467511)*lambda^2*(lambda^2-0.018592511)/((lambda^2-0.018592511)^2 +0.015379669*lambda^2));  % Quartz
