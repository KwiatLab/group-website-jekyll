function W = evaluate_weighting_func_for_searchRia(beta_i, crystal_param, w, lambda_pump, lambda_s, s_pump, s_s, R);

%function [W, n_s_slow, n_i_slow] = evaluate_weighting_func_for_search(beta_i, crystal_param, w, lambda_pump, lambda_s, s_pump, s_s, R);

thickness = crystal_param.crystal_thickness;
lambda_i = 1/(1/lambda_pump - 1/lambda_s);

beta_s = acos(dot(s_pump, s_s));
% n_bar is vector normal to plane containing the pump and the down converted photons
n_bar = cross(s_pump, s_s);
s_i = rotate_vector(s_pump, n_bar, beta_i);

% the pump photon must be of the fast polarization for down conversion to occur
[temp, n_pump_fast] = find_n1_and_n2_top(crystal_param, lambda_pump, s_pump);
k_z_pump = 2*pi*n_pump_fast/lambda_pump*s_pump(3); 

% the daughter photons have the slow polarization in the crystal they were born in
[n_s_slow, temp] = find_n1_and_n2_top(crystal_param, lambda_s, s_s);

[n_i_slow, temp] = find_n1_and_n2_top(crystal_param, lambda_i, s_i);

delta_k = n_pump_fast/lambda_pump*s_pump - n_s_slow/lambda_s*s_s - n_i_slow/lambda_i*s_i;
% minimize the momentum conservation condition in the pump propagation direction
delta_k_z = delta_k(3);

% minimize the momentum conservation condition in the pump transverse direction
delta_k_trans = sqrt(delta_k(1)^2 + delta_k(2)^2); 

% % make the radius of curvature in microns
% R = R*1000;
%W = -abs(1/w*exp(-1/4*delta_k_trans^2*R*w^2/(4*R + 2*i*k_z_pump*w^2))/(i*k_z_pump/R + 2/w^2)*sin(1/(2*pi)*thickness*delta_k_z)/(1/(2*pi)*thickness*delta_k_z));
%W = pi*w*exp(-1/4*w^2*delta_k_trans^2)*sin(1/(2*pi)*thickness*delta_k_z)/(1/(2*pi)*thickness*delta_k_z);

%Tried1
%W = (1-(exp(-1/4*w^2*delta_k_trans^2)*sin(1/(2)*thickness*delta_k_z)/(1/(2)*thickness*delta_k_z));
%W = (1-(exp(-1/4*w^2*delta_k_trans^2)*sin(1/(2)*thickness*delta_k_z)/(1/(2)*thickness*delta_k_z));
W = (1-exp(-1/2*w^2*delta_k_trans^2)*sin(1/(2)*thickness*delta_k_z)/(1/(2)*thickness*delta_k_z));