%plot_d_eff_vs_phi_BiBO
%This program plots the phasematching angle, theta, and d_eff as functions of phi
%for the case of Type I Second Harmonic Generation (SHG))

%This program uses an approximate phasematching expression for SHG, eq 2.50 on p.22
%of Dmitriev, V.G., G.G. Gurzadyan, and D.N. Nikogosyan, "Handbook of Nonlinear 
%Optical Crystals, 3rd Revised Edition" (Springer, NY, 1999).

npoints = 500; %number of plot points
lambda_1 = 0.810; %degenerate wavelengths from Type I downconversion
lambda_3 = lambda_1/2; %pump wavelength
% theta = [151.7 28.3];  %thetas to be plotted
phi2=linspace(0,90,npoints); %range of phi values plotted
phi=phi2*pi/180;
indices_1 = bibo_principal_indices(lambda_1);
indices_3 = bibo_principal_indices(lambda_3);
%Define some constants for the phasematching calculation
n_1z=indices_1(3);
n_1y=indices_1(2);
n_1x=indices_1(1);
n_3z=indices_3(3);
n_3y=indices_3(2);
n_3x=indices_3(1);
K_1= 1./(sqrt(n_1z^-2 - n_1x^-2 + (n_1x^-2 - n_1y^-2)*sin(phi)));
%calculate the phasematching angle, theta, as a function of phi
theta_1 = asind(K_1.*sqrt(n_3y^-2 - n_1x^-2 + (n_1x^-2 - n_1y^-2 + n_3x^-2 - n_3y^-2).*sin(phi).^2));
%calculate the complementary angle to the phasemactching angle
theta_2 = 180 - theta_1;

%Calculate d_eff as a function of theta and phi
for ii=1:1:npoints
d_eff_1c1(ii)=d_eff_BiBO(theta_1(ii), phi2(ii), lambda_1);
d_eff_1d1(ii)=d_eff_BiBO(theta_2(ii), phi2(ii), lambda_1);
d_eff_2c1(ii)=d_eff_BiBO2(theta_1(ii), phi2(ii), lambda_1);
d_eff_2d1(ii)=d_eff_BiBO2(theta_2(ii), phi2(ii), lambda_1);
end

%Make the plots 
%(Note that Tzankov refers to the paper: Tzankov, Pancho and
%Valentin Petrov, "Effective second-order nonlinearity in  accentric
%optical crystals", Applied Optics 44, 6971-6985 (2005) and Ghotbi refers
%to Ghotbi M. and M. Ebrahim-Zadeh, "Optical harmonic generation properti.s
%of BiB_3O_6", Optics Express 12, 6002 (2004).)
figure(5)
subplot(2,1,1)
plot(phi2,theta_1,phi2,theta_2)
title(['\lambda_1 = ' num2str(lambda_1*1000) 'nm, b=x']);
xlabel('\phi (^\circ)');
ylabel('\theta (^\circ)');
% legend(['\theta = ' num2str(theta(1))], ['\theta = ' num2str(theta(2))]);

% subplot(3,1,2)
% plot(phi2,d_eff_1c1,phi2,-d_eff_1d1)
% title(['\lambda_1 = ' num2str(lambda_1*1000) 'nm, b=x, Tzankov values for nonlinear coefficients']);
% xlabel('\phi (^\circ)');
% ylabel('d_{eff} (pm/V)');
% legend('\theta < 90^\circ', '\theta > 90^\circ');

subplot(2,1,2)
plot(phi2,d_eff_2c1,phi2,-d_eff_2d1)
title(['\lambda_1 = ' num2str(lambda_1*1000) 'nm, b=x, Ghotbi values for nonlinear coefficients']);
xlabel('\phi (^\circ)');
ylabel('d_{eff} (pm/V)');
legend('\theta < 90^\circ', '\theta > 90^\circ');

% hgsave(figfilename)