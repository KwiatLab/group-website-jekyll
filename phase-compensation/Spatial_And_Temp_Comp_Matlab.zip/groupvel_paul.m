lambda=0.788;       %lambdasignal in mikrometer
lambdap=0.788;       %lambdapump
L=1e-3;                 %Kristalldicke in m
c=3e8;                    %c in meter/sekunde

thetap=30.5*pi/180;  %Schnittwinkel Kristall


   
   %Formeln f�r n^2(lambda) aus 'handbook on nonlin optics'
   no2=2.7359 + 0.01878/(lambda^2-0.01822) - 0.01354*lambda^2;
   ne2=2.3753 + 0.01224/(lambda^2-0.01667) - 0.01516*lambda^2;
   
   %n^2(lambda/2) f�r die pumpe
   %np2(n)=2.3753 + 0.01224/(lambda(n)^2/4-0.01667) - 0.01516*lambda(n)^2/4;
   nop2=2.7359 + 0.01878/(lambdap^2-0.01822) - 0.01354*lambdap^2;

      
   %Erweiterung ne^2(lambda) abh. von theta
   ne2th=no2/(1+ (no2/ne2 - 1)*sin(thetap)^2);
   
   no=sqrt(no2);
   ne=sqrt(ne2);
   nop=sqrt(nop2);
   neth=sqrt(ne2th);
   
   %Ableitungen lambda*d(n)/d(lambda) f�r die diversen n(lambda)
   lambdadnopdlambda=-(1/nop)*lambdap^2*(0.01878/(lambdap^2-0.01822)^2 + 0.01354); %Pumpe
   lambdadnodlambda=-(1/no)*lambda^2*(0.01878/(lambda^2-0.01822)^2 + 0.01354);       %Signal
   lambdadnedlambda=-(1/ne)*lambda^2*(0.01224/(lambda^2-0.01667)^2 + 0.01516);       %Extraod. @90�
   lambdadnethdlambda=neth^3*(cos(thetap)^2*lambdadnodlambda/no^3 + ...
      sin(thetap)^2*lambdadnedlambda/ne^3);                                          %Extraordinary @theta
   
   %Gruppenvel. f�r diverse lambdas und n
   vopinverse=nop-lambdadnopdlambda;
   %veinverse(n)=ne(n)-lambdadnedlambda(n);
   vethinverse=neth-lambdadnethdlambda;
   
   %d(n)=(voinverse(n)-veinverse(n))*L*10^15/c;
   dth=(vopinverse-vethinverse)*L*1e15/c             %Answer ~ Timedelay between HH and VV in [fs]
 
   %dplus(n,m)=(0.5*(voinverse(n)+vethinverse(n,m))-1/vp(n))*L*10^15/c;
%end
%end
%plot(lambda,no,lambda,ne);
%figure;
%plot(lambda/2,np);
%figure;
%plot(lambda,veth);
%figure;
%plot(lambda,vo,lambda,ve,lambda,veth,lambda,vp);
%figure;
%plot(lambda,d,lambda,dth(:,1),lambda,dth(:,2),lambda,dth(:,3),lambda,dth(:,4),lambda,dth(:,5));
%figure;
%plot(lambda,d,lambda,dth);
%figure;
%plot(lambda,dplus);