function [m, s_out] = equation_to_minimize(s_out_tang, crystal_param, lambda, n1_or_n2, s_in, n_in);
% this function calculates m = n_in_sin(theta_in) - n_out*sin(theta_out), which is the
% deviation from perfect Snell's law refraction for the chosen output angle and given
% input angle and refractive index

% input side is medium outside of the crystal, typically air, having index n_in
% output side is inside the crystal
% the interface is always assumed to be in the x-y plane

s_in = s_in/norm(s_in);

x_in = s_in(1);
y_in = s_in(2);
z_in = s_in(3);

% calculate the tangential component of the input vector 
s_in_tang = sqrt(x_in^2 + y_in^2);

% if input vector is normal to the inteface, no refraction occurs
if (s_in == [0;0;1])
    s_out = [0;0;1];
    m = 0;
else
    z_out = sqrt(1-s_out_tang^2);
    y_out = sqrt((1-z_out^2)*y_in^2/(x_in^2+y_in^2))*sign(y_in);
    x_out = sqrt(1-y_out^2-z_out^2)*sign(x_in);
    
    s_out = [x_out; y_out; z_out]; 
    
    [n_slow, n_fast] = find_n1_and_n2_top(crystal_param, lambda, s_out);
    if (n1_or_n2 == 1)
        n_out = n_slow;
    else
        n_out = n_fast;
    end

    m = n_in*s_in_tang - n_out*s_out_tang;
end