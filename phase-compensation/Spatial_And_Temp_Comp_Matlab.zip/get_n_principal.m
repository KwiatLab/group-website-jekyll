function x = get_n_principal(crystal_type, lambda)

% Outputs a vector containing the three principal indices of refraction for a particlar crystal
% The vector is of form [nx; ny; nz]
% lambda is in microns

global custom_crystals;

if (crystal_type == 'BiBO')
    x = bibo_principal_indices(lambda);
elseif (crystal_type == 'BBO2')
    x = [n_o_BBO(lambda); n_o_BBO(lambda); n_e_BBO(lambda)];
elseif (crystal_type == 'BBO1')
    x = BBO_ref1_principal_indices(lambda);
elseif (crystal_type == 'Quar')
    x = [n_o_quartz(lambda); n_o_quartz(lambda); n_e_quartz(lambda)];

% custom pre-compensator crystal
elseif (crystal_type == 'cst1')
    x = custom_n(custom_crystals.cst1, lambda);
    
% custom first DC crystal
elseif (crystal_type == 'cst2')
    x = custom_n(custom_crystals.cst2, lambda);
    
% custom second DC crystal
elseif (crystal_type == 'cst3')
    x = custom_n(custom_crystals.cst3, lambda);

% custom signal spatial comp crystal
elseif (crystal_type == 'cst4')
    x = custom_n(custom_crystals.cst4, lambda);

% custom idler spatial comp crystal
elseif (crystal_type == 'cst5')
    x = custom_n(custom_crystals.cst5, lambda);    
    
else
    x = [1; 1; 1];
end

