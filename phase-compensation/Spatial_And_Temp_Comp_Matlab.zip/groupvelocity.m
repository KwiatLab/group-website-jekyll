lambda=(0.6:0.05:1.5);
%lambda in mikrometer
L=1*10^(-3);
%Kristalldicke in m
c=3*10^8;
%c in meter/sekunde

for m=1:5

thetap(m)=(20+m*10)*pi/180;


for n=1:length(lambda)
   
   %Formeln f�r n^2(lambda) aus 'handbook on nonlin optics'
   no2(n)=2.7359 + 0.01878/(lambda(n)^2-0.01822) - 0.01354*lambda(n)^2;
   ne2(n)=2.3753 + 0.01224/(lambda(n)^2-0.01667) - 0.01516*lambda(n)^2;
   
   %n^2(lambda/2) f�r die pumpe
   np2(n)=2.3753 + 0.01224/(lambda(n)^2/4-0.01667) - 0.01516*lambda(n)^2/4;
      
   %Erweiterung ne^2(lambda) abh. von theta
   ne2th(n,m)=no2(n)/(1+ (no2(n)/ne2(n) - 1)*sin(thetap(m))^2);
   
   no(n)=sqrt(no2(n));
   ne(n)=sqrt(ne2(n));
   np(n)=sqrt(np2(n));
   neth(n,m)=sqrt(ne2th(n,m));
   
   %Ableitungen lambda*d(n)/d(lambda) f�r die diversen n(lambda)
   lambdadnodlambda(n)=-(1/no(n))*lambda(n)^2*(0.01878/(lambda(n)^2-0.01822)^2 + 0.01354);
   lambdadnedlambda(n)=-(1/ne(n))*lambda(n)^2*(0.01224/(lambda(n)^2-0.01667)^2 + 0.01516);
   lambdadnethdlambda(n,m)=neth(n,m)^3*(cos(thetap(m))^2*lambdadnodlambda(n)/no(n)^3 + ...
      sin(thetap(m))^2*lambdadnedlambda(n)/ne(n)^3);
   
   %Gruppenvel. f�r diverse lambdas und n
   voinverse(n)=no(n)-lambdadnodlambda(n);
   veinverse(n)=ne(n)-lambdadnedlambda(n);
   vethinverse(n,m)=neth(n,m)-lambdadnethdlambda(n,m);
   
   d(n)=(voinverse(n)-veinverse(n))*L*10^15/c;
   dth(n,m)=(voinverse(n)-vethinverse(n,m))*L*10^15/c;
 
   dplus(n,m)=(0.5*(voinverse(n)+vethinverse(n,m))-1/vp(n))*L*10^15/c;
end
end
%plot(lambda,no,lambda,ne);
figure;
%plot(lambda/2,np);
%figure;
%plot(lambda,veth);
%figure;
%plot(lambda,vo,lambda,ve,lambda,veth,lambda,vp);
%figure;
plot(lambda,d,lambda,dth(:,1),lambda,dth(:,2),lambda,dth(:,3),lambda,dth(:,4),lambda,dth(:,5));
figure;
plot(lambda,d,lambda,dth);
figure;
plot(lambda,dplus);