function T=tangle(rho)
% Usage T=tangle(rho);
%
% Returns the tangle of the two-qubit density matrix rho or a
% two-qubit state vector.

  C=concurrence(rho);
  T = C^2;
  
