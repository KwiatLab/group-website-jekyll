function [vg_slow, vg_fast] = group_velocities(crystal_param, lambda, k)

% indices of horizontal and vertical pump in first crystal
[n_slow, n_fast] = find_n1_and_n2_top(crystal_param, lambda, k);

% find indices for a slightly higher wavelength to calculate the
% derivative dn/dlambda which is needed to calculate the group velocity
[n_slow_temp, n_fast_temp] = find_n1_and_n2_top(crystal_param, lambda + .00001, k);

dn_dlambda_slow = (n_slow_temp - n_slow)/(0.00001);
dn_dlambda_fast = (n_fast_temp - n_fast)/(0.00001);

% output the group velocity for slow and fast polarizations
% speed of light is in um/s
vg_slow = 2.9979e14/(n_slow - lambda*dn_dlambda_slow);
vg_fast = 2.9979e14/(n_fast - lambda*dn_dlambda_fast);
