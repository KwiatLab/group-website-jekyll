function n = n_e_theta(n_o, n_e, theta)

% Returns the extraordinary index of refraction for a beam at an angle theta from the optic axis.

n = n_o*sqrt((1 + tan(theta)^2)/(1+(n_o/n_e*tan(theta))^2));