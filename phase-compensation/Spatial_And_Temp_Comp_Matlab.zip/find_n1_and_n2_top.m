function [n_slow, n_fast] = find_n1_and_n2_top(crystal_param, lambda, s_lab_int);

% This function finds the fast and slow refractive indices for a unit direction vector s_lab_int and wavelength lambda
% See Yariv and Yeh, chapter 4 for an explanation of the process for finding the indices in a biaxial/uniaxial crystal
crystal_type = crystal_param.crystal_type;
theta = crystal_param.theta;
phi = crystal_param.phi;
gamma = crystal_param.gamma;

s_lab_int = s_lab_int/norm(s_lab_int);

% Transform propagation vector inside the crystal, s_lab_int, to crystal coordinates
s_crystal_int = transform_lab_to_crystal(s_lab_int, theta, phi, gamma);

% Get the principal indices of refraction for this crystal
n_principal = get_n_principal(crystal_type, lambda);

% Calculate the transformation matrix from the crystal coordinates to a coordinate system in 
% which s_crystal_int points in the [0;0;1] direction (called the s coordinates)
crystal_to_s_coord = crystal_to_s_coord_matrix(s_crystal_int);

% Calculate the transverse permeability matrix in the s coordinates (see function for more
% details)
eta_transverse = get_eta_transverse(n_principal, crystal_to_s_coord);

% Calculate the fast and slow indices of refraction corresponding to propagation vector, s
x = find_n1_and_n2(eta_transverse);

n_slow = x(1);
n_fast = x(2);

