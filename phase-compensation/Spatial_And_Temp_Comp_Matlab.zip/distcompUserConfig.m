function allConfigs = distcompUserConfig()
%distcompUserConfig Return all the user configurations for the Distributed 
%Computing Toolbox as a cell array of function handles.
%
%   Copy this file to a directory that is higher on your MATLAB path than
%   MATLABROOT/toolbox/distcomp/user and edit so that it accurately reflects
%   your scheduler and how you want to run your jobs.
%
%   The most common way of modifying this file is to identify your scheduler
%   and customize the corresponding subfunction.
%    - If you are using a job manager, customize the 'jobmanager' subfunction
%    - If you are using LSF, customize the 'lsf' subfunction
%    - If you are using CCS, customize the 'ccs' subfunction
%    - If you are using the generic scheduler interface, customize the 'generic'
%    subfunction
%    - If you are using the mpiexec scheduler interface, customize the 'mpiexec'
%    subfunction
%
%   This API is subject to change in a future release.  Please be aware that the
%   configurations you enter in this file may need to be moved to a new API at a
%   later date.

%   Copyright 2005-2006 The MathWorks, Inc.
%   $Revision: 1.1.10.5 $  $Date: 2006/12/06 01:36:34 $

% In addition to modifying the configurations shown below, you can add new
% configurations.  If you want to create a new configuration called 'myconfig',
% add the subfunction myconfig to this file, and add the function handle
% @myconfig to the following cell array.

allConfigs = {@GogginManager, @ccs, @mpiexec, @local};

function conf = GogginManager()
%CCS Return a sample configuration for a CCS cluster.
%   You might want to assign values to DataLocation and to PathDependencies.

    %% Parameters to the findResource command
    % See the help for findResource for more information.
    % This is required for this configuration to be complete:
    conf.findResource.Type = 'jobmanager';

    %% CCS scheduler properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc DataLocation
        
    % This is required for this configuration to be complete:
    conf.jobmanagerscheduler.DataLocation = '\\ece-hpcstore\mgoggin'; %where xxxxxxx is your share on ece-hpcstore
    conf.jobmanagerscheduler.HasSharedFileSystem = true;
        
    % If you have a network install of matlab the setting below will make
    % ClusterMatlabRoot the same as the matlabroot of the current matlab
    conf.jobmanagerscheduler.ClusterMatlabRoot = dctReplaceDriveWithUNCPath(matlabroot);    
    conf.jobmanagerscheduler.SchedulerHostname = 'ece-hpc-01.ece.uiuc.edu';
    
    
    %% Job properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc PathDependencies    
    conf.job.PathDependencies = {'\\ece-hpcstore\mgoggin'}; %where xxxxxx is your share on ece-hpcstore
    conf.job.FileDependencies = {}; % .m files that you wish to include with your job
    
    %% Task properties
    % Use the doc command to obtain more information about these properties.
    % For example:  doc CaptureCommandWindowOutput
    conf.task.CaptureCommandWindowOutput = false;
    
function conf = ccs()
%CCS Return a sample configuration for a CCS cluster.
%   You might want to assign values to DataLocation and to PathDependencies.

    %% Parameters to the findResource command
    % See the help for findResource for more information.
    % This is required for this configuration to be complete:
    conf.findResource.Type = 'ccs';

    %% CCS scheduler properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc DataLocation
        
    % This is required for this configuration to be complete:
    conf.ccsscheduler.DataLocation = '\\ece-hpcstore\mgoggin'; %where xxxxxxx is your share on ece-hpcstore
    conf.ccsscheduler.HasSharedFileSystem = true;
        
    % If you have a network install of matlab the setting below will make
    % ClusterMatlabRoot the same as the matlabroot of the current matlab
    conf.ccsscheduler.ClusterMatlabRoot = dctReplaceDriveWithUNCPath(matlabroot);    
    conf.ccsscheduler.SchedulerHostname = 'ece-hpc-01.ece.uiuc.edu';
    
    
    %% Job properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc PathDependencies    
    conf.job.PathDependencies = {'\\ece-hpcstore\mgoggin'}; %where xxxxxx is your share on ece-hpcstore
    conf.job.FileDependencies = {}; % .m files that you wish to include with your job
    
    %% Task properties
    % Use the doc command to obtain more information about these properties.
    % For example:  doc CaptureCommandWindowOutput
    conf.task.CaptureCommandWindowOutput = false;
    
function conf = mpiexec()
%MPIEXEC Return a sample configuration for the mpiexec scheduler.
%   You might want to assign values to DataLocation, PathDependencies and 
%   MaximumNumberOfWorkers.    

    %% Parameters to the findResource command
    % See the help for findResource for more information.
    % This is required for this configuration to be complete:
    conf.findResource.Type = 'mpiexec';

    %% mpiexec scheduler properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc DataLocation
    % This is required for this configuration to be complete:
    %conf.mpiexec.DataLocation = '\\ece-hpcstore\mgoggin';
    % conf.mpiexec.MpiexecFilename = '';
    conf.mpiexec.HasSharedFileSystem = true;
    conf.mpiexec.ClusterMatlabRoot = dctReplaceDriveWithUNCPath(matlabroot);
    conf.mpiexec.ClusterMatlabRoot = '';

    conf.mpiexec.SubmitArguments = '';
    conf.mpiexec.EnvironmentSetMethod = '-env';
    conf.mpiexec.ClusterOsType = 'pc';
    
  
    
    %% Parallel job properties 
    % Use the doc command to obtain more information about these properties.
    % For example:  doc PathDependencies    
    conf.paralleljob.PathDependencies = {'\\ece-hpcstore\mgoggin'};
    conf.paralleljob.FileDependencies = {};
    % This is required to be a finite number for this configuration to be
    % complete:
    conf.paralleljob.MinimumNumberOfWorkers = 5;
    conf.paralleljob.MaximumNumberOfWorkers = 5;
    % mpiexec does not use the MinimumNumberOfWorkers property.
    % conf.paralleljob.MinimumNumberOfWorkers = 1;
    
    %% Task properties
    % Use the doc command to obtain more information about these properties.
    % For example:  doc CaptureCommandWindowOutput
    conf.task.CaptureCommandWindowOutput = false;

function conf = local()

    conf.findResource.Type = 'local';
