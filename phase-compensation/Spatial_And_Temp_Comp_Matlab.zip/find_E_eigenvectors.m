% All inputs and outputs for this function are in crystal coordinates

function x = find_E_eigenvectors(n_principal, D_eigenvectors)

% This is the dielectric tensor without epsilon_not in front
dielectric_tensor = [(n_principal(1))^2 0 0; 0 (n_principal(2))^2 0; 0 0 (n_principal(3))^2];

% eta is the impermeability tensor
eta = inv(dielectric_tensor);

% Electric field eigenvectors (in crystal coordinates), up to a factor of epsilon_not
E1 = eta*D_eigenvectors(:,1);
E2 = eta*D_eigenvectors(:,2);

% Normalize eigenvectors because we are only interested in direction
E1_norm = E1/norm(E1);
E2_norm = E2/norm(E2);


x = [E1_norm E2_norm];