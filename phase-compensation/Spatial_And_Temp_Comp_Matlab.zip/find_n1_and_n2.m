function x = find_n1_and_n2(eta_transverse)

[V,D] = eig(eta_transverse);

n1 = 1/sqrt(D(1,1));
n2 = 1/sqrt(D(2,2));

if (n1 < n2)
    n1_temp = n1;
    n2_temp = n2;
    n1 = n2_temp;
    n2 = n1_temp;
end

% n1 is slow and n2 is fast
x = [n1; n2];

end