function tangle = precomp()
clear
figfilename_root = 'test';
figfilename = [figfilename_root '.fig'];

tic
disp('Initialize parameters')

npoints = 10; %Number of pre-comp thicknesses to calculate
plot_map=0; %Produce plot of phase map for each point? 1=yes
flip_fix_on = 1; %Fix flip problem for BiBO calculation? 1=yes
comp_on = 0; %Calculate spatial compensation? 1=yes
custom_coeff = 0; %Use custom Sellmeier coefficients (user supplied)? 1=yes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%uncomment the block corresponding to the crystal you want to use and     %
%comment out the block corresponding to the crystal you do not want to use%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dc_crystals = 'BiBO';
% dc_d=0.6; %units=mm
% dc1theta = 151.7; %units=degrees
% dc2theta = 151.7; %units=degrees
% dc1phi = 90; %units=degrees
% dc2phi = 90; %units=degrees
% dc1gamma = 0; %units=degrees
% dc2gamma = 90; %units=degrees
% pc_crystal = 'Quar';
% pre_comp_d = linspace(10.0, 20.0, npoints); %units=mm
% pctheta = 90; %units=degrees
% pcphi = 0; %units=degrees
% pcgamma = 90; %units=degrees
% 

dc_crystals = 'BBO1';
dc_d=0.6; %units=mm
dc1theta = 29.24; %units=degrees
dc2theta = 29.24; %units=degrees
dc1phi = 0; %units=degrees
dc2phi = 0; %units=degrees
dc1gamma = 0; %units=degrees
dc2gamma = 90; %units=degrees
pc_crystal = 'Quar';
pre_comp_d = linspace(0, 10.0, npoints); %units=mm
pctheta = 90; %units=degrees
pcphi = 0; %units=degrees
pcgamma = 0; %units=degrees
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


data_mark = ['-gs';'-bo';'-kp';'-kh';'-kx'];

lambda_pump = 405.0; %units=nm

delta_lambda = 2; %Full width between 1/e points units=nm
%signal and idler center wavelengths are defined by the filters
lambda_signal = 810.0; %units=nm
lambda_idler = 810.0; %units=nm
filter_pts=10; %Number of frequencies sampled
pump_waist=1.0; %units=mm
pump_rad_curv=1e9; %units=mm
iris_pts=3; %Number of points sampled in each direction on signal iris.  A total of iris_pts^2 are calculated.
iris_diam_i=0.5; %units=mm
iris_diam_s=0.5; %units=mm

% nmodes=length(mode_weights);

%convert wavelengths and thicknesses to microns
dc_thick=dc_d*1000;
pre_comp_d=pre_comp_d*1000;
% mode_spacing_0 = mode_spacing_0/1000;
% delta_lambda_0 = delta_lambda_0/1000;
delta_lambda = delta_lambda/1000;
lambda_pump = lambda_pump/1000;
pump_w=pump_waist*1000;
pump_R=pump_rad_curv*1000;
lambda_signal = lambda_signal/1000;
lambda_idler = lambda_idler/1000;

%convert angles from degrees to radians
dc1theta = dc1theta*pi/180;
dc2theta = dc2theta*pi/180;
dc1phi=dc1phi*pi/180;
dc2phi = dc2phi*pi/180;
dc1gamma = dc1gamma*pi/180;
dc2gamma = dc2gamma*pi/180;
pctheta = pctheta*pi/180;
pcphi = pcphi*pi/180;
pcgamma = pcgamma*pi/180;

comp_s = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, pi/2);
comp_i = set_crystal_param('BBO1', 245, 33.9*pi/180, 0, -pi/2);
dc_1 = set_crystal_param(dc_crystals(1,:), dc_thick, dc1theta, dc1phi, dc1gamma);
dc_2 = set_crystal_param(dc_crystals(1,:), dc_thick, dc2theta, dc2phi, dc2gamma);
filters = set_filters(lambda_signal, 0.05, lambda_idler, 0.05, filter_pts, filter_pts);
irises = set_irises([0;42.56;812], iris_diam_s/2, [0;-42.56;812], iris_diam_i/2, iris_pts, iris_pts, iris_pts, iris_pts, pump_w);

format compact

disp('Begin calculation')

pump = set_pump([cos(pi/4); sin(pi/4); 0], pump_w, 1e9, lambda_pump, delta_lambda);

tangle = zeros(1, npoints);
precomp_d = zeros(1, npoints);

for ii = 1: 1: npoints
    pre_comp = set_crystal_param(pc_crystal, pre_comp_d(ii), pctheta, pcphi, pcgamma);


[rho, T, phases, param, slow_flips, fast_flips, dc_flips] = phasemap_and_rho_tempcomp(irises, filters,...
pre_comp, dc_1, dc_2, comp_s, comp_i, pump, comp_on, custom_coeff, plot_map);


    tangle(ii) = T;
    precomp_d(ii) = pre_comp_d(ii)/1000;
    disp(['Point ' num2str(ii) ' of ' num2str(npoints) ' points calculated.'])
        rho_T_array(ii).s_comp = comp_s;
    rho_T_array(ii).i_comp = comp_i;
    rho_T_array(ii).dc1 = dc_1;
    rho_T_array(ii).dc2 = dc_2;
    rho_T_array(ii).Tangle = T;
    rho_T_array(ii).Rho = rho;
end
calctime=toc;
disp(['Calculation took ' num2str(calctime) ' seconds'])
for kk=1:1:9
    if slow_flips(kk)~=0
        disp(['slow_flips(' num2str(kk) ') = ' num2str(slow_flips(kk)) ', corrected'])
    end
    if fast_flips(kk)~=0
        disp(['fast_flips(' num2str(kk) ') = ' num2str(fast_flips(kk)) ', corrected'])
    end
end
disp([num2str(param.iris_hits) ' photon pairs hit both irises out of ' num2str(param.max_hits) ' tries.'])
disp(['maximum signal radius at iris = ' num2str(param.max_dist_s) ', maximum idler radius at iris = ' num2str(param.max_dist_i)])
%p = polyfit(precomp_d, tangle, 2)
%pval = polyval(p, precomp_d)
figure
plot(precomp_d, tangle, '-d');
xlabel('d (mm)');
ylabel('Tangle');
set(gca,'position',[0.15 0.1 0.65 0.7]); 
title({[pc_crystal ' precompensator, $\lambda_{pump} =$ ' num2str(lambda_pump*1000)...
    ' nm, $\Delta\lambda =$ ' num2str(delta_lambda*1000) ' nm, filter points = ' num2str(filter_pts)];...
    ['$\lambda_{signal} =$ ' num2str(lambda_signal*1000) ' nm, $\lambda_{idler} =$ ' ...
    num2str(lambda_idler*1000) ' nm, iris pts = ' num2str(iris_pts) ...
    ', iris diam = ' num2str(iris_diam_s)];...
    ['comp on = ' num2str(comp_on) ', ' num2str(dc_crystals) ' DC crystals, ' num2str(dc_d) 'mm thick'];...
    ['Filename = \verb+' figfilename_root '+']}, 'interpreter', 'latex');
hgsave(figfilename)
c=fix(clock);
filename=[figfilename_root '_' num2str(c(1)) '-' num2str(c(2)) '-' num2str(c(3)) '-' num2str(c(4)) '-' num2str(c(5)) '-' num2str(c(6)) '.mat'];
save (filename)