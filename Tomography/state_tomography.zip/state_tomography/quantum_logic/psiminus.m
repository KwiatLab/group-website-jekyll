function psi=psiminus
% Usage: psi=psiminus
% 
% Returns the state HV-VH -- the singlet state psi^-.


psi = [0; 1; -1; 0]/sqrt(2);
