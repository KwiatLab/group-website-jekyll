function S=rho2stokes(rho)
% Usage: S = rho2stokes(rho)
%
% The generalized stokes vector is defined as:
% rho = 1/N * (sum_{i=1}^{N} S(i) * \sigma_i)
% where \sigma_i are the spinor matricies for rho.
%
% Currently, rho2stokes is limited to the case of N qubits,
% where the appropriate \sigma_i are simply tensor products of the
% Pauli matricies.

if(min(size(rho)) == 1)
  rho = rho * rho';
end

d = length(rho);
N = d^2;

S = zeros(N,1);
for j=1:N
%  sigma_str = dec2base(j-1, 4, d);
%  sigma_vec = str2num(sigma_str')';
%  sigma_vec = multiloop_index(j, 4*ones(1,d))-1;
%  S(j) = trace(rho*sigma(sigma_vec));
   S(j) = trace(rho*sigma_N(j, d));
end
