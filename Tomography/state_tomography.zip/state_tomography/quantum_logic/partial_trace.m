function t=partial_trace(rho, n, D)
% Usage val=partial_trace(rho, n, D)
%
% Return the reduced density matrix after tracing over all outcomes
% for the n'th part.  rho is divided into parts according to the
% vector D containing the dimentions of each part.  If D is not
% specified, the size of rho must be a power of two, and is assumed to
% be a collection of log2(length(n)) qubits.

  if(nargin < 3)
    n_qubit = log2(size(rho, 1));
    if(~mod(n_qubit, 1))
      D = 2 * ones(1,n_qubit);
    else
      error(['partial_trace: dimention of rho is not power of ' ...
             '2.']);
    end
  end
  Na = prod(D(1:n-1));
  Nb = D(n);
  Nc = prod(D(n+1:length(D)));
  
  if (Na == 1)
    t = partial_trace_first(rho, Nb);
  else
    sub_sizes = Nb*Nc;
    Y = mat2cell(rho, sub_sizes * ones(1,Na), sub_sizes * ones(1, Na));
    
    for j=1:Na
      for k=1:Na
        Y{j,k} = partial_trace_first(Y{j,k}, Nb);
      end
    end
    t = cell2mat(Y);
  end

function val=partial_trace_first(M, d)
% Computes the partial transpose of the first part of M with
% dimention d.

  if (size(M, 1) == d)
    val = trace(M);
  else
    Na = d;
    Nb = size(M, 1)/d;
    Y = mat2cell(M, Nb * ones(1,Na), Nb * ones(1, Na));
    diag_m = diag(Y);
    tr = 0;
    for j = 1:length(diag_m)
      tr = tr + diag_m{j};
    end
    val = tr;
  end
