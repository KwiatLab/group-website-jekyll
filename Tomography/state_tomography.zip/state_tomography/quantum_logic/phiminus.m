function psi=phiminus
% Usage: psi=phiminus
% 
% Returns the state HH-VV -- the bell state phi^-.


psi = [1; 0; 0; -1]/sqrt(2);
