function [alpha, beta, lambda]=schmidt_decomposition(psi, d1)
% Usage: [alpha, beta, lambda] = schmidt_decomposition(psi, d1)
%
% Calculates the schmidt decomposition of the bipartite state psi.
% d1 is the dimention of the first part, d1 must divide
% length(psi).  If d1 is not give, the two parts are assumed to
% have the same dimentionality.  sqrt(length(psi)) must be an
% integer.

if(nargin < 2)
  d1 = sqrt(length(psi));
end
d2 = length(psi) / d1;

a = reshape(psi, d2, d1).';

[U,S,V] = svd(a);

tmp = diag(S);
n = sum(abs(tmp) > 1e-10);
lambda = tmp(1:n);

alpha = U(:,1:n);
beta = conj(V(:, 1:n));

if(nargout <= 1)
	alpha = lambda;
end
