function val=rotation_2d(theta)
% Usage: matrix=rotation_2d(theta)
%
% Gives the rotation matrix for a rotation of theta radians about
% the origin.

val = [cos(theta) sin(theta) ;
      -sin(theta) cos(theta) ];
