function val=bell_fidelity(rho)
% Usage: val=bell_fidelity(rho)
%
% Calculates the fidelity of the two qubit density matrix rho with a
% bell-like state of the form |HH> + exp(i*theta)|VV> -- ie, like the
% phi+ and phi- states but without regard to the phase.

phase = angle(rho(1,4));

tmp = [1 0 0 a; 0 0 0 0; 0 0 0 0; a' 0 0 1] / 2;
val = fidelity(tmp, rho);
