function val=negativity(rho)
% Usage: val=negativity(rho)
%
% The negativity of a quantum state is the absolute value of the
% negative eigenvalue in the partial transpose, or zero 

  if(min(size(rho)) == 1)
    rho = rho*rho';
  end
  
  rho1 = partial_transpose(rho, 1);
  val=-2*min(min(eig(rho1)),0);
