function psi=psiplus
% Usage: psi=psiplus
% 
% Returns the state HV+VH -- the bell state psi^+.

psi = [0; 1; 1; 0]/sqrt(2);
