function val=one_in(idx, length)
% Usage: val=one_in(idx, length)
%
% Generates a column vector with a single '1';

val=zeros(length,1);
val(idx)=1;
