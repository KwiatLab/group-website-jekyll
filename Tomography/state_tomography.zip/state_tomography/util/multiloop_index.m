function ind=multiloop_index(j, lengths)
% Usage: ind=multiloop_index(j, lengths)
%
% Represents a single loop counter 'j' as an array of loop
% counters.  The i'th loop has lengths(i) iterations, with the last
% index varying most quickly.


if (nargin ~= 2)
  error ('Usage: multiloop_index(j, lengths)');
end
  
if (prod (size (j)) ~= length (j))
  error ('multiloop_index: cannot convert matrices.');
elseif (any (j < 0 | j ~= fix (j)))
  error (['multiloop_index: can only convert non-negative ' 'integers.']);
elseif (any(j > prod(lengths)))
  error('multiloop_index: index can not exceed prod(lengths)');
end
  
% determine number of digits required to handle all numbers
j = j - 1;
ind = zeros(length(j), length(lengths));
for k=1:length(lengths)-1
  sz = prod(lengths(k+1:end));
  ind(:,k) = fix(j/sz)+1;
  j = rem(j, sz);
end
ind(:, end) = j+1;
