function t=density2t(rho)
% Usage: density2t(rho)
%
% Converts a n-dimentional density matrix into a real vector
% containing the coefficients of the t_matrix -- a lower triangular
% matrix with the property that t_matrix'*t_matrix = rho.  This is
% used as the parameterization for searching over density matricies
% in the maximum liklihood program.

tm = density2tm(rho);

d = length(tm);

idx=1;
cur_length=d;
t = zeros(d^2,1);

for j=1:d
  t(idx:idx+cur_length-1) = real(diag(tm, 1-j));
  idx = idx + cur_length;
  
  if(j > 1)
    t(idx:idx+cur_length-1) = imag(diag(tm, 1-j));
    idx = idx + cur_length;
  end
  cur_length = cur_length - 1;
end
