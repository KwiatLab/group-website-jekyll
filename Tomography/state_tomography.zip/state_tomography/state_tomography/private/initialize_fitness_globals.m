function [A,B]=initialize_fitness_globals(M)
% Usage: initialize_fitness_globals(M)
%
% Internal use. initializes some private variables for use in
% maxlike_fitness.  A and B are cell vectors of arrays.  
% A_j = t_matrix(one_in(j, length)) * M', B = A'.
%
% 
num_t = size(M, 1)^2; % number of t_matricies
num_M = size(M,3);
M_size = size(M,1);

A = cell(num_M, num_t);
B = A;

tm = cell(num_t,1);

for j=1:num_t
  tm{j} = t_matrix(one_in(j,num_t));
end

for j=1:num_M
  for k=1:num_t
    A{j,k} = sparse(M(:,:,j)*tm{k}');
    B{j,k} = sparse(tm{k}*M(:,:,j));
  end
end
