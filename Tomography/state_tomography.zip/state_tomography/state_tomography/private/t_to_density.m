function rho=t_to_density(t)
% Usage: rho=t_to_density(t)
%
% Converts a 't' vector of real elements into a density matrix.

tm = t_matrix(t);
rho = tm' * tm;
