function [rho, intensity, fval]=state_tomography(raw_counts, intensities, conf)
% Usage: [rho, intensity, fval]=state_tomography(raw_counts, intensities, conf)
%
% Master function for running a tomography of a quantum system.

rho0 = getfield_default(conf, 'RhoStart', []);
ndet = conf.NDetectors; % It is an error not to specify this: we
                        % need to know how to interpret raw_counts

if(ndet == 2);
  [data, M1, M2, acc, conf] = filter_data_2n(raw_counts, intensities, conf);
else
  [data, M1, M2, acc, conf] = filter_data_n(raw_counts, intensities, conf);
end

if(isempty(rho0))
  [rho0, intensity0] = linear_tomography(data, M2);
end

[rho,intensity, fval]=maximum_likelihood_tomography(rho0, data, M1, acc, conf);
