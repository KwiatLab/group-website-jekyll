function [rho,intensity, fval]=maximum_likelihood_tomography(rho0, data, ...
                                                  M, acc, conf)
% Usage: [rho,intensity, fval]=maximum_likelihood_tomography(rho0, data, M, errors, conf)
%
% Finds the best estimate of the state 'rho' represented by a
% series of measurements.  data containes a vector of the processed
% counts, while M contains the measurements associated with each
% measurement.  rho0 is an initial starting guess -- usually
% derived from a linear tomography.  It need not be positive
% semi-definite, but should be hermetian.  conf is passed without
% comment to the fitness function, which uses it to enable special
% features.

% Only the diagonal and lower triangle part of rho0 are used.  The
% upper triangle is not used, and assumed to match the lower
% triagonal.

rho0 = make_positive(rho0);
rho0 = rho0/trace(rho0);
init_intensity=mean(data)*size(rho0,1);
t0 = density2t(rho0);
n_t = length(t0);

t_to_density(t0);
t0 = t0+.0001;
t0 = t0*sqrt(init_intensity);

intmap = getfield_default(conf, 'IntensityMap', 1);
n_int = size(intmap, 2)-1;
t0 = [t0;ones(n_int, 1)];

options = optimset('Display', 'off', 'Jacobian', 'on', 'DerivativeCheck', ...
                   'off');%, 'TolFun', .001);

useder = getfield_default(conf, 'UseDerivatives', 1);
if(ischar(useder))
  useder = strcmpi(useder, 'yes');
end
if(~useder)
%  warning('Not using derivatives');
  options = optimset('Display', 'off', 'Jacobian', 'off');
end
[A, B] = initialize_fitness_globals(M);

tmp=maxlike_fitness(t0, data, acc, M, conf, A, B);
[t, fval] = lsqnonlin(@maxlike_fitness, t0, [], [], options, data, ...
                      acc, M, conf, A, B);

base_intensity = sum(t(1:n_t).^2);
%[ignore, jacob] = maxlike_fitness(t, data, acc, M, conf, A, B);
t_matrix(t(1:n_t));
matrix = t_to_density(t(1:n_t));
intensity = trace(matrix);
rho = matrix / intensity;
