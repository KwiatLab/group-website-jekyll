function [means, errs, mean_fid]= tomography_errors(raw_data, ...
                                                  intensities, 2ndet, ...
                                                  errfunc, n)
% Calculates the statistical error in the output of a tomography,
% based on the data given.
%
% errfunc is a cell array of function handles specifying which
% functions to calculate the error in.  Examples include @tangle,
% @entropy, and inline('fidelity(x, psiminus)', 0).  If n is
% specified, it is the number of trials to use in determining the
% error.  Otherwise should be choosen semi-smartly but is currently
% hard-coded to 100.

if(nargin < 5)
  n = 100;
end

rho0 = state_tomography(raw_data, intensities, 2ndet);

n_fun = length(errfunc);
data = zeros(n, n_fun);
fid = zeros(n, 1);

for j=1:n
  test_data = poissrnd(raw_data(:,1:8));
  test_data = [test_data, raw_data(:,9:end)];
  rho=state_tomography(test_data, intensities, 2ndet);
  fid(j) = fidelity(rho0, rho);
  for k=1:n_fun
    data(j,k) = feval(errfunc{k}, rho);
  end
end
errs = std(data);
means = mean(data);
mean_fid = mean(fid);
